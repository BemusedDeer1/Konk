package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TaskPriority(val displayName: String, val weight: Int) {
  LOW("Low", 1),
  MEDIUM("Medium", 2),
  HIGH("High", 3),
  URGENT("Urgent", 4)
}

enum class LifeArea(val title: String, val iconName: String) {
  CAREER("Career & Work", "work"),
  HEALTH("Health & Fitness", "fitness_center"),
  LEARNING("Learning & Growth", "school"),
  MINDSET("Mindset & Well-being", "self_improvement"),
  FINANCE("Finance & Wealth", "payments"),
  RELATIONSHIPS("Relationships", "group"),
  CREATIVITY("Creativity & Projects", "palette")
}

enum class ProjectStatus(val title: String) {
  NOT_STARTED("Not Started"),
  IN_PROGRESS("In Progress"),
  ON_HOLD("On Hold"),
  COMPLETED("Completed")
}

enum class GoalStatus(val title: String) {
  ACTIVE("Active"),
  ACHIEVED("Achieved"),
  PAUSED("Paused")
}

@Entity(tableName = "tasks")
data class TaskEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val description: String = "",
  val isCompleted: Boolean = false,
  val priority: String = TaskPriority.MEDIUM.name,
  val dueDate: String? = null, // YYYY-MM-DD
  val scheduledDate: String? = null, // YYYY-MM-DD
  val estimatedMinutes: Int = 30,
  val actualMinutes: Int = 0,
  val projectId: Long? = null,
  val goalId: Long? = null,
  val tags: String = "", // comma-separated
  val notes: String = "",
  val recurrence: String = "NONE", // NONE, DAILY, WEEKLY
  val createdAt: Long = System.currentTimeMillis(),
  val completedAt: Long? = null,
  val isArchived: Boolean = false
)

@Entity(tableName = "projects")
data class ProjectEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val description: String = "",
  val colorHex: String = "#8B7CFF",
  val targetDate: String? = null,
  val status: String = ProjectStatus.IN_PROGRESS.name,
  val priority: String = TaskPriority.MEDIUM.name,
  val category: String = LifeArea.CAREER.name,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "goals")
data class GoalEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val description: String = "",
  val category: String = LifeArea.CAREER.name,
  val targetDate: String? = null,
  val targetMetric: Double = 100.0,
  val currentMetric: Double = 0.0,
  val metricUnit: String = "%",
  val milestonesJson: String = "[]", // e.g. [{"title":"Phase 1","done":true}]
  val status: String = GoalStatus.ACTIVE.name,
  val motivation: String = "",
  val nextAction: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "habits")
data class HabitEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val description: String = "",
  val category: String = LifeArea.HEALTH.name,
  val targetDaysPerWeek: Int = 7,
  val streakCurrent: Int = 0,
  val streakBest: Int = 0,
  val colorHex: String = "#42D6A4",
  val reminderTime: String = "08:00",
  val isArchived: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "habit_logs")
data class HabitLogEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val habitId: Long,
  val dateString: String, // YYYY-MM-DD
  val isCompleted: Boolean = true,
  val note: String = ""
)

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val durationMinutes: Int,
  val completedAt: Long = System.currentTimeMillis(),
  val linkedTaskId: Long? = null,
  val linkedGoalId: Long? = null,
  val notes: String = "",
  val distractionCount: Int = 0
)

@Entity(tableName = "notes")
data class NoteEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val content: String,
  val tags: String = "",
  val isPinned: Boolean = false,
  val isFavorite: Boolean = false,
  val linkedProjectId: Long? = null,
  val linkedGoalId: Long? = null,
  val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_plans")
data class DailyPlanEntity(
  @PrimaryKey val dateString: String, // YYYY-MM-DD
  val mainPriority: String = "",
  val outcome1: String = "",
  val outcome2: String = "",
  val outcome3: String = "",
  val reflectionNotes: String = "",
  val rating: Int = 0 // 1 to 5 stars
)

@Entity(tableName = "user_profile")
data class UserProfileEntity(
  @PrimaryKey val id: Int = 1,
  val name: String = "Explorer",
  val language: String = "en", // "en" or "fa"
  val themeMode: String = "SYSTEM", // SYSTEM, DARK, LIGHT
  val focusMinutesDefault: Int = 25,
  val dailyTargetHours: Int = 6,
  val weeklyReviewDay: String = "Sunday",
  val onboardingCompleted: Boolean = false,
  val xpPoints: Int = 120,
  val level: Int = 1
)
