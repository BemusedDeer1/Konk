package com.example.data

import com.example.model.DailyPlanEntity
import com.example.model.FocusSessionEntity
import com.example.model.GoalEntity
import com.example.model.GoalStatus
import com.example.model.HabitEntity
import com.example.model.HabitLogEntity
import com.example.model.LifeArea
import com.example.model.NoteEntity
import com.example.model.ProjectEntity
import com.example.model.ProjectStatus
import com.example.model.TaskEntity
import com.example.model.TaskPriority
import com.example.model.UserProfileEntity
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AscendRepository(private val db: AscendDatabase) {

  val allTasks: Flow<List<TaskEntity>> = db.taskDao().getAllTasksFlow()
  val allProjects: Flow<List<ProjectEntity>> = db.projectDao().getAllProjectsFlow()
  val allGoals: Flow<List<GoalEntity>> = db.goalDao().getAllGoalsFlow()
  val allHabits: Flow<List<HabitEntity>> = db.habitDao().getAllHabitsFlow()
  val allHabitLogs: Flow<List<HabitLogEntity>> = db.habitLogDao().getAllLogsFlow()
  val allSessions: Flow<List<FocusSessionEntity>> = db.focusSessionDao().getAllSessionsFlow()
  val allNotes: Flow<List<NoteEntity>> = db.noteDao().getAllNotesFlow()
  val userProfile: Flow<UserProfileEntity?> = db.userDao().getUserProfileFlow()

  fun getTasksForDate(date: String): Flow<List<TaskEntity>> = db.taskDao().getTasksForDateFlow(date)
  fun getHabitLogsForDate(date: String): Flow<List<HabitLogEntity>> = db.habitLogDao().getLogsForDateFlow(date)
  fun getDailyPlan(date: String): Flow<DailyPlanEntity?> = db.dailyPlanDao().getDailyPlanFlow(date)

  suspend fun insertTask(task: TaskEntity): Long = db.taskDao().insertTask(task)
  suspend fun updateTask(task: TaskEntity) = db.taskDao().updateTask(task)
  suspend fun deleteTask(task: TaskEntity) = db.taskDao().deleteTask(task)

  suspend fun insertProject(project: ProjectEntity): Long = db.projectDao().insertProject(project)
  suspend fun updateProject(project: ProjectEntity) = db.projectDao().updateProject(project)
  suspend fun deleteProject(project: ProjectEntity) = db.projectDao().deleteProject(project)

  suspend fun insertGoal(goal: GoalEntity): Long = db.goalDao().insertGoal(goal)
  suspend fun updateGoal(goal: GoalEntity) = db.goalDao().updateGoal(goal)
  suspend fun deleteGoal(goal: GoalEntity) = db.goalDao().deleteGoal(goal)

  suspend fun insertHabit(habit: HabitEntity): Long = db.habitDao().insertHabit(habit)
  suspend fun updateHabit(habit: HabitEntity) = db.habitDao().updateHabit(habit)
  suspend fun deleteHabit(habit: HabitEntity) = db.habitDao().deleteHabit(habit)

  suspend fun logHabit(habitId: Long, date: String, isDone: Boolean) {
    if (isDone) {
      db.habitLogDao().insertLog(HabitLogEntity(habitId = habitId, dateString = date, isCompleted = true))
      // Update streak
      val habit = db.habitDao().getHabitById(habitId)
      if (habit != null) {
        val newStreak = habit.streakCurrent + 1
        val bestStreak = maxOf(habit.streakBest, newStreak)
        db.habitDao().updateHabit(habit.copy(streakCurrent = newStreak, streakBest = bestStreak))
      }
    } else {
      db.habitLogDao().deleteLogForHabitAndDate(habitId, date)
      val habit = db.habitDao().getHabitById(habitId)
      if (habit != null && habit.streakCurrent > 0) {
        db.habitDao().updateHabit(habit.copy(streakCurrent = habit.streakCurrent - 1))
      }
    }
  }

  suspend fun recordFocusSession(session: FocusSessionEntity) {
    db.focusSessionDao().insertSession(session)
    // Add XP to user
    val profile = db.userDao().getUserProfile() ?: UserProfileEntity()
    val earnedXp = session.durationMinutes * 4
    val updatedXp = profile.xpPoints + earnedXp
    val newLevel = (updatedXp / 200) + 1
    db.userDao().insertOrUpdateProfile(profile.copy(xpPoints = updatedXp, level = newLevel))
  }

  suspend fun insertNote(note: NoteEntity): Long = db.noteDao().insertNote(note)
  suspend fun updateNote(note: NoteEntity) = db.noteDao().updateNote(note)
  suspend fun deleteNote(note: NoteEntity) = db.noteDao().deleteNote(note)

  suspend fun saveDailyPlan(plan: DailyPlanEntity) = db.dailyPlanDao().insertOrUpdateDailyPlan(plan)
  suspend fun saveUserProfile(profile: UserProfileEntity) = db.userDao().insertOrUpdateProfile(profile)

  suspend fun checkAndSeedInitialData() {
    val existingProfile = db.userDao().getUserProfile()
    if (existingProfile == null) {
      val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

      db.userDao().insertOrUpdateProfile(
        UserProfileEntity(
          id = 1,
          name = "Alex",
          language = "en",
          themeMode = "SYSTEM",
          focusMinutesDefault = 25,
          dailyTargetHours = 6,
          weeklyReviewDay = "Sunday",
          onboardingCompleted = true,
          xpPoints = 240,
          level = 2
        )
      )

      val proj1 = db.projectDao().insertProject(
        ProjectEntity(
          name = "Ascend Life Architecture",
          description = "Design habits, routines, and systems for relentless progression",
          colorHex = "#8B7CFF",
          targetDate = today,
          status = ProjectStatus.IN_PROGRESS.name,
          priority = TaskPriority.HIGH.name,
          category = LifeArea.CAREER.name
        )
      )
      val proj2 = db.projectDao().insertProject(
        ProjectEntity(
          name = "Vitality & Peak Health",
          description = "Physical endurance, strength training, and nutrition protocols",
          colorHex = "#42D6A4",
          targetDate = today,
          status = ProjectStatus.IN_PROGRESS.name,
          priority = TaskPriority.MEDIUM.name,
          category = LifeArea.HEALTH.name
        )
      )

      val goal1 = db.goalDao().insertGoal(
        GoalEntity(
          title = "Achieve 20 Hours of Deep Work Weekly",
          description = "Distraction-free high-leverage execution blocks on core projects",
          category = LifeArea.CAREER.name,
          targetDate = today,
          targetMetric = 20.0,
          currentMetric = 14.5,
          metricUnit = "hrs",
          milestonesJson = "[{\"title\":\"Establish 9am deep work block\",\"done\":true},{\"title\":\"Eliminate phone from desk\",\"done\":true},{\"title\":\"Log 20h for 3 consecutive weeks\",\"done\":false}]",
          motivation = "Deep focus compounds skills and accelerates career breakthroughs."
        )
      )

      db.goalDao().insertGoal(
        GoalEntity(
          title = "Master Persian Vocabulary & Script",
          description = "Learn 500 essential idioms and read fluent conversational text",
          category = LifeArea.LEARNING.name,
          targetDate = today,
          targetMetric = 500.0,
          currentMetric = 180.0,
          metricUnit = "words",
          milestonesJson = "[{\"title\":\"Alphabet & basic phonetics\",\"done\":true},{\"title\":\"Common phrases & numbers\",\"done\":true},{\"title\":\"Read short essays\",\"done\":false}]",
          motivation = "Bilingual cognitive agility and cultural richness."
        )
      )

      val tasks = listOf(
        TaskEntity(
          title = "Review quarterly life priorities & OKRs",
          description = "Clarify top 3 needle-moving targets for the coming months",
          isCompleted = false,
          priority = TaskPriority.HIGH.name,
          dueDate = today,
          scheduledDate = today,
          estimatedMinutes = 35,
          projectId = proj1,
          goalId = goal1,
          tags = "Strategy,Planning"
        ),
        TaskEntity(
          title = "Complete 50-minute deep focus session",
          description = "Write core architecture and eliminate distractions",
          isCompleted = true,
          priority = TaskPriority.URGENT.name,
          dueDate = today,
          scheduledDate = today,
          estimatedMinutes = 50,
          actualMinutes = 52,
          projectId = proj1,
          goalId = goal1,
          tags = "DeepWork"
        ),
        TaskEntity(
          title = "Afternoon cardio & movement session",
          description = "Zone 2 aerobic exercise and active mobility stretching",
          isCompleted = false,
          priority = TaskPriority.MEDIUM.name,
          dueDate = today,
          scheduledDate = today,
          estimatedMinutes = 40,
          projectId = proj2,
          tags = "Fitness,Health"
        ),
        TaskEntity(
          title = "Read 20 pages of cognitive philosophy",
          description = "Highlight actionable frameworks on habits and focus",
          isCompleted = false,
          priority = TaskPriority.LOW.name,
          dueDate = today,
          scheduledDate = today,
          estimatedMinutes = 30,
          tags = "Reading,Mindset"
        )
      )
      db.taskDao().insertAllTasks(tasks)

      val habit1 = db.habitDao().insertHabit(
        HabitEntity(
          title = "Morning Alignment & Plan",
          description = "Review top 3 priorities before opening email or social media",
          category = LifeArea.MINDSET.name,
          targetDaysPerWeek = 7,
          streakCurrent = 6,
          streakBest = 14,
          colorHex = "#8B7CFF"
        )
      )
      val habit2 = db.habitDao().insertHabit(
        HabitEntity(
          title = "Hydration Protocol (2.5L)",
          description = "Water and electrolytes throughout the day",
          category = LifeArea.HEALTH.name,
          targetDaysPerWeek = 7,
          streakCurrent = 11,
          streakBest = 21,
          colorHex = "#42D6A4"
        )
      )
      val habit3 = db.habitDao().insertHabit(
        HabitEntity(
          title = "Deep Focus Timer Block",
          description = "At least one uninterrupted 25-minute Pomodoro session",
          category = LifeArea.CAREER.name,
          targetDaysPerWeek = 5,
          streakCurrent = 4,
          streakBest = 12,
          colorHex = "#F5B942"
        )
      )
      val habit4 = db.habitDao().insertHabit(
        HabitEntity(
          title = "Evening Reflection & Gratitude",
          description = "Note 1 win, 1 lesson, and prepare tomorrow's plan",
          category = LifeArea.MINDSET.name,
          targetDaysPerWeek = 7,
          streakCurrent = 3,
          streakBest = 9,
          colorHex = "#FF75A0"
        )
      )

      // Seed today's check-ins for habit 1 & 2
      db.habitLogDao().insertLog(HabitLogEntity(habitId = habit1, dateString = today, isCompleted = true))
      db.habitLogDao().insertLog(HabitLogEntity(habitId = habit2, dateString = today, isCompleted = true))

      // Seed recent focus sessions
      db.focusSessionDao().insertSession(
        FocusSessionEntity(
          title = "Architecture & Deep Work",
          durationMinutes = 50,
          completedAt = System.currentTimeMillis() - 3600_000 * 3,
          linkedTaskId = 2,
          notes = "Very high flow state. No phone interruptions."
        )
      )
      db.focusSessionDao().insertSession(
        FocusSessionEntity(
          title = "Persian Study Sprint",
          durationMinutes = 25,
          completedAt = System.currentTimeMillis() - 3600_000 * 24,
          notes = "Flashcards and grammar practice."
        )
      )

      // Seed Daily Plan
      db.dailyPlanDao().insertOrUpdateDailyPlan(
        DailyPlanEntity(
          dateString = today,
          mainPriority = "Deliver the Ascend system core and protect deep work hours",
          outcome1 = "Complete system build & verify test passing",
          outcome2 = "Hit 2 uninterrupted focus sessions",
          outcome3 = "Reflect on weekly trajectory with zero distractions",
          reflectionNotes = "Energy levels stayed high when breaks were taken deliberately.",
          rating = 5
        )
      )

      // Seed Notes
      db.noteDao().insertNote(
        NoteEntity(
          title = "The Law of Sustainable Momentum",
          content = "Progress does not require perfection; it requires recovery after disruption. When a streak breaks, start immediately with the next smallest viable action rather than feeling defeated. Consistency beats intensity.",
          tags = "Principles,Mindset",
          isPinned = true,
          isFavorite = true,
          linkedProjectId = proj1
        )
      )
      db.noteDao().insertNote(
        NoteEntity(
          title = "Deep Work Protocol Rules",
          content = "1. Phone outside arm reach.\n2. One browser tab only.\n3. Water glass filled.\n4. Clear definition of done before pressing start.\n5. Log distractions on a sticky note to handle later.",
          tags = "Focus,Execution",
          isPinned = true,
          isFavorite = false
        )
      )
    }
  }
}
