package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.model.DailyPlanEntity
import com.example.model.FocusSessionEntity
import com.example.model.GoalEntity
import com.example.model.HabitEntity
import com.example.model.HabitLogEntity
import com.example.model.NoteEntity
import com.example.model.ProjectEntity
import com.example.model.TaskEntity
import com.example.model.UserProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
  @Query("SELECT * FROM tasks WHERE isArchived = 0 ORDER BY isCompleted ASC, priority DESC, createdAt DESC")
  fun getAllTasksFlow(): Flow<List<TaskEntity>>

  @Query("SELECT * FROM tasks WHERE id = :id")
  suspend fun getTaskById(id: Long): TaskEntity?

  @Query("SELECT * FROM tasks WHERE isCompleted = 0 AND isArchived = 0")
  fun getActiveTasksFlow(): Flow<List<TaskEntity>>

  @Query("SELECT * FROM tasks WHERE (dueDate = :date OR scheduledDate = :date) AND isArchived = 0")
  fun getTasksForDateFlow(date: String): Flow<List<TaskEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTask(task: TaskEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAllTasks(tasks: List<TaskEntity>)

  @Update
  suspend fun updateTask(task: TaskEntity)

  @Delete
  suspend fun deleteTask(task: TaskEntity)

  @Query("DELETE FROM tasks WHERE id = :id")
  suspend fun deleteTaskById(id: Long)
}

@Dao
interface ProjectDao {
  @Query("SELECT * FROM projects ORDER BY createdAt DESC")
  fun getAllProjectsFlow(): Flow<List<ProjectEntity>>

  @Query("SELECT * FROM projects WHERE id = :id")
  suspend fun getProjectById(id: Long): ProjectEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProject(project: ProjectEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAllProjects(projects: List<ProjectEntity>)

  @Update
  suspend fun updateProject(project: ProjectEntity)

  @Delete
  suspend fun deleteProject(project: ProjectEntity)
}

@Dao
interface GoalDao {
  @Query("SELECT * FROM goals ORDER BY createdAt DESC")
  fun getAllGoalsFlow(): Flow<List<GoalEntity>>

  @Query("SELECT * FROM goals WHERE id = :id")
  suspend fun getGoalById(id: Long): GoalEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGoal(goal: GoalEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAllGoals(goals: List<GoalEntity>)

  @Update
  suspend fun updateGoal(goal: GoalEntity)

  @Delete
  suspend fun deleteGoal(goal: GoalEntity)
}

@Dao
interface HabitDao {
  @Query("SELECT * FROM habits WHERE isArchived = 0 ORDER BY createdAt DESC")
  fun getAllHabitsFlow(): Flow<List<HabitEntity>>

  @Query("SELECT * FROM habits WHERE id = :id")
  suspend fun getHabitById(id: Long): HabitEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertHabit(habit: HabitEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAllHabits(habits: List<HabitEntity>)

  @Update
  suspend fun updateHabit(habit: HabitEntity)

  @Delete
  suspend fun deleteHabit(habit: HabitEntity)
}

@Dao
interface HabitLogDao {
  @Query("SELECT * FROM habit_logs WHERE dateString = :date")
  fun getLogsForDateFlow(date: String): Flow<List<HabitLogEntity>>

  @Query("SELECT * FROM habit_logs ORDER BY dateString DESC")
  fun getAllLogsFlow(): Flow<List<HabitLogEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertLog(log: HabitLogEntity): Long

  @Query("DELETE FROM habit_logs WHERE habitId = :habitId AND dateString = :date")
  suspend fun deleteLogForHabitAndDate(habitId: Long, date: String)
}

@Dao
interface FocusSessionDao {
  @Query("SELECT * FROM focus_sessions ORDER BY completedAt DESC")
  fun getAllSessionsFlow(): Flow<List<FocusSessionEntity>>

  @Query("SELECT * FROM focus_sessions ORDER BY completedAt DESC LIMIT 20")
  fun getRecentSessionsFlow(): Flow<List<FocusSessionEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSession(session: FocusSessionEntity): Long
}

@Dao
interface NoteDao {
  @Query("SELECT * FROM notes ORDER BY isPinned DESC, updatedAt DESC")
  fun getAllNotesFlow(): Flow<List<NoteEntity>>

  @Query("SELECT * FROM notes WHERE id = :id")
  suspend fun getNoteById(id: Long): NoteEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNote(note: NoteEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAllNotes(notes: List<NoteEntity>)

  @Update
  suspend fun updateNote(note: NoteEntity)

  @Delete
  suspend fun deleteNote(note: NoteEntity)
}

@Dao
interface DailyPlanDao {
  @Query("SELECT * FROM daily_plans WHERE dateString = :date")
  fun getDailyPlanFlow(date: String): Flow<DailyPlanEntity?>

  @Query("SELECT * FROM daily_plans WHERE dateString = :date")
  suspend fun getDailyPlan(date: String): DailyPlanEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateDailyPlan(plan: DailyPlanEntity)
}

@Dao
interface UserDao {
  @Query("SELECT * FROM user_profile WHERE id = 1")
  fun getUserProfileFlow(): Flow<UserProfileEntity?>

  @Query("SELECT * FROM user_profile WHERE id = 1")
  suspend fun getUserProfile(): UserProfileEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrUpdateProfile(profile: UserProfileEntity)
}

@Database(
  entities = [
    TaskEntity::class,
    ProjectEntity::class,
    GoalEntity::class,
    HabitEntity::class,
    HabitLogEntity::class,
    FocusSessionEntity::class,
    NoteEntity::class,
    DailyPlanEntity::class,
    UserProfileEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class AscendDatabase : RoomDatabase() {
  abstract fun taskDao(): TaskDao
  abstract fun projectDao(): ProjectDao
  abstract fun goalDao(): GoalDao
  abstract fun habitDao(): HabitDao
  abstract fun habitLogDao(): HabitLogDao
  abstract fun focusSessionDao(): FocusSessionDao
  abstract fun noteDao(): NoteDao
  abstract fun dailyPlanDao(): DailyPlanDao
  abstract fun userDao(): UserDao

  companion object {
    @Volatile
    private var INSTANCE: AscendDatabase? = null

    fun getDatabase(context: Context): AscendDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AscendDatabase::class.java,
          "ascend_os.db"
        )
          .fallbackToDestructiveMigration(true)
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
