package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiClient
import com.example.data.AscendDatabase
import com.example.data.AscendRepository
import com.example.model.DailyPlanEntity
import com.example.model.FocusSessionEntity
import com.example.model.GoalEntity
import com.example.model.HabitEntity
import com.example.model.HabitLogEntity
import com.example.model.NoteEntity
import com.example.model.ProjectEntity
import com.example.model.TaskEntity
import com.example.model.UserProfileEntity
import com.example.ui.navigation.AscendDestination
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatMessage(
  val sender: String, // "user" or "ai"
  val text: String,
  val timestamp: Long = System.currentTimeMillis()
)

class AscendViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: AscendRepository

  init {
    val db = AscendDatabase.getDatabase(application)
    repository = AscendRepository(db)
    viewModelScope.launch {
      repository.checkAndSeedInitialData()
    }
  }

  val todayDate: String
    get() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

  val tasks: StateFlow<List<TaskEntity>> = repository.allTasks.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val projects: StateFlow<List<ProjectEntity>> = repository.allProjects.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val goals: StateFlow<List<GoalEntity>> = repository.allGoals.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val habits: StateFlow<List<HabitEntity>> = repository.allHabits.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val habitLogs: StateFlow<List<HabitLogEntity>> = repository.allHabitLogs.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val focusSessions: StateFlow<List<FocusSessionEntity>> = repository.allSessions.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val notes: StateFlow<List<NoteEntity>> = repository.allNotes.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val userProfile: StateFlow<UserProfileEntity?> = repository.userProfile.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), null
  )

  val dailyPlan: StateFlow<DailyPlanEntity?> = repository.getDailyPlan(todayDate).stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), null
  )

  // Navigation state
  private val _currentDestination = MutableStateFlow(AscendDestination.HOME)
  val currentDestination: StateFlow<AscendDestination> = _currentDestination.asStateFlow()

  private val _destinationStack = mutableListOf(AscendDestination.HOME)

  fun navigateTo(dest: AscendDestination) {
    if (_currentDestination.value != dest) {
      _destinationStack.add(dest)
      _currentDestination.value = dest
    }
  }

  fun navigateBack(): Boolean {
    return if (_destinationStack.size > 1) {
      _destinationStack.removeAt(_destinationStack.size - 1)
      _currentDestination.value = _destinationStack.last()
      true
    } else {
      false
    }
  }

  // Filter & Search
  private val _taskSearchQuery = MutableStateFlow("")
  val taskSearchQuery = _taskSearchQuery.asStateFlow()
  fun setTaskSearchQuery(query: String) { _taskSearchQuery.value = query }

  private val _taskFilter = MutableStateFlow("ALL") // ALL, TODAY, HIGH, COMPLETED
  val taskFilter = _taskFilter.asStateFlow()
  fun setTaskFilter(filter: String) { _taskFilter.value = filter }

  // Focus Timer State
  private val _timerTotalSeconds = MutableStateFlow(25 * 60)
  val timerTotalSeconds = _timerTotalSeconds.asStateFlow()

  private val _timerRemainingSeconds = MutableStateFlow(25 * 60)
  val timerRemainingSeconds = _timerRemainingSeconds.asStateFlow()

  private val _isTimerRunning = MutableStateFlow(false)
  val isTimerRunning = _isTimerRunning.asStateFlow()

  private val _isTimerPaused = MutableStateFlow(false)
  val isTimerPaused = _isTimerPaused.asStateFlow()

  private val _activeFocusTask = MutableStateFlow<TaskEntity?>(null)
  val activeFocusTask = _activeFocusTask.asStateFlow()

  private val _distractionCount = MutableStateFlow(0)
  val distractionCount = _distractionCount.asStateFlow()

  private var timerJob: Job? = null

  fun setTimerDuration(minutes: Int) {
    if (!_isTimerRunning.value) {
      val secs = minutes * 60
      _timerTotalSeconds.value = secs
      _timerRemainingSeconds.value = secs
    }
  }

  fun setFocusTask(task: TaskEntity?) {
    _activeFocusTask.value = task
  }

  fun logDistraction() {
    _distractionCount.value += 1
  }

  fun startTimer() {
    if (_isTimerRunning.value && _isTimerPaused.value) {
      _isTimerPaused.value = false
      launchTimerJob()
      return
    }

    _isTimerRunning.value = true
    _isTimerPaused.value = false
    launchTimerJob()
  }

  fun pauseTimer() {
    _isTimerPaused.value = true
    timerJob?.cancel()
  }

  fun resetTimer() {
    timerJob?.cancel()
    _isTimerRunning.value = false
    _isTimerPaused.value = false
    _timerRemainingSeconds.value = _timerTotalSeconds.value
    _distractionCount.value = 0
  }

  fun completeTimer() {
    val elapsedSecs = _timerTotalSeconds.value - _timerRemainingSeconds.value
    val elapsedMins = maxOf(1, elapsedSecs / 60)
    val task = _activeFocusTask.value

    viewModelScope.launch {
      repository.recordFocusSession(
        FocusSessionEntity(
          title = task?.title ?: "Deep Focus Block",
          durationMinutes = elapsedMins,
          completedAt = System.currentTimeMillis(),
          linkedTaskId = task?.id,
          linkedGoalId = task?.goalId,
          distractionCount = _distractionCount.value,
          notes = if (_distractionCount.value == 0) "Zero distractions - Flow achieved!" else "${_distractionCount.value} distractions recorded."
        )
      )
      if (task != null) {
        val updated = task.copy(actualMinutes = task.actualMinutes + elapsedMins)
        repository.updateTask(updated)
      }
    }
    resetTimer()
  }

  private fun launchTimerJob() {
    timerJob?.cancel()
    timerJob = viewModelScope.launch {
      while (_timerRemainingSeconds.value > 0) {
        delay(1000)
        _timerRemainingSeconds.value -= 1
      }
      completeTimer()
    }
  }

  // AI Assistant Chat State
  private val _aiMessages = MutableStateFlow(
    listOf(
      ChatMessage(
        sender = "ai",
        text = "Welcome to **ASCEND AI**. I am your personal planning architect. I can organize your today, split complex goals into micro-milestones, or calculate a recovery schedule after missed days. What would you like to achieve?"
      )
    )
  )
  val aiMessages = _aiMessages.asStateFlow()

  private val _isAiLoading = MutableStateFlow(false)
  val isAiLoading = _isAiLoading.asStateFlow()

  fun sendAiPrompt(prompt: String) {
    if (prompt.isBlank()) return
    val userMsg = ChatMessage(sender = "user", text = prompt)
    _aiMessages.value = _aiMessages.value + userMsg
    _isAiLoading.value = true

    viewModelScope.launch {
      val responseText = GeminiClient.askAssistant(
        userPrompt = prompt,
        systemContext = "Ascend OS Personal Assistant",
        tasks = tasks.value,
        goals = goals.value,
        habits = habits.value
      )
      _aiMessages.value = _aiMessages.value + ChatMessage(sender = "ai", text = responseText)
      _isAiLoading.value = false
    }
  }

  // Dialog & Modal Sheet controls
  var showTaskDialog = MutableStateFlow(false)
  var editingTask = MutableStateFlow<TaskEntity?>(null)

  var showGoalDialog = MutableStateFlow(false)
  var editingGoal = MutableStateFlow<GoalEntity?>(null)

  var showHabitDialog = MutableStateFlow(false)
  var editingHabit = MutableStateFlow<HabitEntity?>(null)

  var showProjectDialog = MutableStateFlow(false)
  var editingProject = MutableStateFlow<ProjectEntity?>(null)

  var showNoteDialog = MutableStateFlow(false)
  var editingNote = MutableStateFlow<NoteEntity?>(null)

  var showMoreSheet = MutableStateFlow(false)

  // Task Actions
  fun saveTask(task: TaskEntity) {
    viewModelScope.launch {
      if (task.id == 0L) {
        repository.insertTask(task)
        // Award creation XP
        awardXp(15)
      } else {
        repository.updateTask(task)
      }
    }
  }

  fun toggleTaskCompletion(task: TaskEntity) {
    viewModelScope.launch {
      val isNowCompleted = !task.isCompleted
      val updated = task.copy(
        isCompleted = isNowCompleted,
        completedAt = if (isNowCompleted) System.currentTimeMillis() else null
      )
      repository.updateTask(updated)
      if (isNowCompleted) {
        awardXp(50)
      }
    }
  }

  fun deleteTask(task: TaskEntity) {
    viewModelScope.launch { repository.deleteTask(task) }
  }

  // Habit Actions
  fun saveHabit(habit: HabitEntity) {
    viewModelScope.launch {
      if (habit.id == 0L) {
        repository.insertHabit(habit)
        awardXp(20)
      } else {
        repository.updateHabit(habit)
      }
    }
  }

  fun toggleHabitToday(habitId: Long, isDone: Boolean) {
    viewModelScope.launch {
      repository.logHabit(habitId, todayDate, isDone)
      if (isDone) {
        awardXp(30)
      }
    }
  }

  fun deleteHabit(habit: HabitEntity) {
    viewModelScope.launch { repository.deleteHabit(habit) }
  }

  // Goal Actions
  fun saveGoal(goal: GoalEntity) {
    viewModelScope.launch {
      if (goal.id == 0L) {
        repository.insertGoal(goal)
        awardXp(40)
      } else {
        repository.updateGoal(goal)
      }
    }
  }

  fun updateGoalProgress(goal: GoalEntity, progress: Double) {
    viewModelScope.launch {
      val updated = goal.copy(currentMetric = progress)
      repository.updateGoal(updated)
    }
  }

  fun deleteGoal(goal: GoalEntity) {
    viewModelScope.launch { repository.deleteGoal(goal) }
  }

  // Project Actions
  fun saveProject(project: ProjectEntity) {
    viewModelScope.launch {
      if (project.id == 0L) {
        repository.insertProject(project)
        awardXp(25)
      } else {
        repository.updateProject(project)
      }
    }
  }

  fun deleteProject(project: ProjectEntity) {
    viewModelScope.launch { repository.deleteProject(project) }
  }

  // Note Actions
  fun saveNote(note: NoteEntity) {
    viewModelScope.launch {
      if (note.id == 0L) {
        repository.insertNote(note)
        awardXp(10)
      } else {
        repository.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
      }
    }
  }

  fun deleteNote(note: NoteEntity) {
    viewModelScope.launch { repository.deleteNote(note) }
  }

  // Daily Plan Actions
  fun savePlan(plan: DailyPlanEntity) {
    viewModelScope.launch {
      repository.saveDailyPlan(plan)
      awardXp(25)
    }
  }

  // Profile & Settings Actions
  fun updateProfile(profile: UserProfileEntity) {
    viewModelScope.launch {
      repository.saveUserProfile(profile)
    }
  }

  private fun awardXp(amount: Int) {
    viewModelScope.launch {
      val current = userProfile.value ?: UserProfileEntity()
      val newXp = current.xpPoints + amount
      val newLevel = (newXp / 200) + 1
      repository.saveUserProfile(current.copy(xpPoints = newXp, level = newLevel))
    }
  }

  fun resetToSampleData() {
    viewModelScope.launch {
      repository.checkAndSeedInitialData()
    }
  }

  fun exportDataAsJson(): String {
    val root = JSONObject()
    root.put("version", "1.0")
    root.put("exportedAt", System.currentTimeMillis())

    val tasksArr = JSONArray()
    tasks.value.forEach { t ->
      tasksArr.put(JSONObject().apply {
        put("title", t.title)
        put("description", t.description)
        put("priority", t.priority)
        put("isCompleted", t.isCompleted)
        put("estimatedMinutes", t.estimatedMinutes)
      })
    }
    root.put("tasks", tasksArr)

    val habitsArr = JSONArray()
    habits.value.forEach { h ->
      habitsArr.put(JSONObject().apply {
        put("title", h.title)
        put("streakCurrent", h.streakCurrent)
        put("targetDaysPerWeek", h.targetDaysPerWeek)
      })
    }
    root.put("habits", habitsArr)

    val goalsArr = JSONArray()
    goals.value.forEach { g ->
      goalsArr.put(JSONObject().apply {
        put("title", g.title)
        put("currentMetric", g.currentMetric)
        put("targetMetric", g.targetMetric)
      })
    }
    root.put("goals", goalsArr)

    return root.toString(2)
  }
}
