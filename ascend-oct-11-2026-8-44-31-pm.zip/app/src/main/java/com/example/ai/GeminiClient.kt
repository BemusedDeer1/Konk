package com.example.ai

import com.example.BuildConfig
import com.example.model.GoalEntity
import com.example.model.HabitEntity
import com.example.model.TaskEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiClient {

  private val client = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  private const val MODEL = "gemini-3.5-flash"
  private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

  suspend fun askAssistant(
    userPrompt: String,
    systemContext: String,
    tasks: List<TaskEntity>,
    goals: List<GoalEntity>,
    habits: List<HabitEntity>
  ): String = withContext(Dispatchers.IO) {
    val apiKey = try {
      BuildConfig.GEMINI_API_KEY
    } catch (_: Exception) {
      ""
    }

    val hasValidKey = apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY"

    if (hasValidKey) {
      try {
        val promptWithData = buildString {
          append(userPrompt)
          append("\n\n--- USER CONTEXT ---")
          append("\nActive Tasks (${tasks.count { !it.isCompleted }}): ")
          tasks.filter { !it.isCompleted }.take(5).forEach {
            append("[${it.priority}] ${it.title} (~${it.estimatedMinutes}m); ")
          }
          append("\nGoals (${goals.size}): ")
          goals.take(3).forEach {
            append("${it.title} (${it.currentMetric}/${it.targetMetric} ${it.metricUnit}); ")
          }
          append("\nHabits (${habits.size}): ")
          habits.take(3).forEach {
            append("${it.title} (streak: ${it.streakCurrent}); ")
          }
        }

        val jsonBody = JSONObject().apply {
          val contentsArray = JSONArray().apply {
            put(JSONObject().apply {
              put("parts", JSONArray().apply {
                put(JSONObject().apply { put("text", promptWithData) })
              })
            })
          }
          put("contents", contentsArray)

          val systemPart = JSONObject().apply {
            put("parts", JSONArray().apply {
              put(JSONObject().apply {
                put("text", "You are ASCEND AI, an elite behavioral psychologist and personal planning architect. Provide concise, high-impact, realistic advice based strictly on user data. Help them design achievable days, avoid overload, and recover gracefully from missed milestones.")
              })
            })
          }
          put("systemInstruction", systemPart)
        }

        val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
        val url = "$BASE_URL/$MODEL:generateContent?key=$apiKey"
        val request = Request.Builder()
          .url(url)
          .post(requestBody)
          .build()

        val response = client.newCall(request).execute()
        if (response.isSuccessful) {
          val responseString = response.body?.string() ?: ""
          val jsonResponse = JSONObject(responseString)
          val candidates = jsonResponse.optJSONArray("candidates")
          if (candidates != null && candidates.length() > 0) {
            val content = candidates.getJSONObject(0).optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text")
            if (!text.isNullOrBlank()) {
              return@withContext text
            }
          }
        }
      } catch (_: Exception) {
        // Fallback to local heuristic engine
      }
    }

    // High quality intelligent local engine fallback when API key is missing or offline
    generateLocalResponse(userPrompt, tasks, goals, habits)
  }

  private fun generateLocalResponse(
    prompt: String,
    tasks: List<TaskEntity>,
    goals: List<GoalEntity>,
    habits: List<HabitEntity>
  ): String {
    val lower = prompt.lowercase()
    val pendingTasks = tasks.filter { !it.isCompleted }
    val urgentTasks = pendingTasks.filter { it.priority == "URGENT" || it.priority == "HIGH" }
    val totalEstHours = pendingTasks.sumOf { it.estimatedMinutes } / 60.0

    return when {
      lower.contains("plan") || lower.contains("today") || lower.contains("schedule") -> {
        buildString {
          append("### 🗓️ Smart Day Architecture\n\n")
          if (urgentTasks.isNotEmpty()) {
            append("**Top Anchor Action:** ${urgentTasks.first().title} (${urgentTasks.first().estimatedMinutes}m)\n\n")
          } else if (pendingTasks.isNotEmpty()) {
            append("**Top Anchor Action:** ${pendingTasks.first().title} (${pendingTasks.first().estimatedMinutes}m)\n\n")
          } else {
            append("**Top Anchor Action:** Review goals and establish your primary milestone.\n\n")
          }
          append("**Recommended Time-Blocking:**\n")
          append("• **Block 1 (Deep Morning):** Focus on your highest leverage task without email or messages.\n")
          append("• **Block 2 (Midday Execution):** Complete secondary tasks and active follow-ups (~${String.format("%.1f", totalEstHours)}h planned).\n")
          append("• **Block 3 (Recovery & Review):** Check off daily habits, log focus minutes, and do a 5-minute reflection.\n\n")
          append("💡 *Guideline:* Never schedule more than 4-5 hours of deep cognitively demanding tasks in one day.")
        }
      }
      lower.contains("break") || lower.contains("split") || lower.contains("step") -> {
        val target = pendingTasks.firstOrNull()?.title ?: "Your Major Milestone"
        buildString {
          append("### 🔨 Actionable Task Decomposition: $target\n\n")
          append("1. **Phase 1: Clarity & Scope (15m)**\n   Define exactly what 'Done' looks like in one clear sentence.\n\n")
          append("2. **Phase 2: Remove Friction & Gather Tools (10m)**\n   Open the exact workspace, outline bullets, and eliminate tabs.\n\n")
          append("3. **Phase 3: Core Sprint 1 (25m Focus)**\n   Produce an imperfect first draft or skeleton implementation.\n\n")
          append("4. **Phase 4: Review & Refine (15m)**\n   Check against success criteria and commit the result.")
        }
      }
      lower.contains("recover") || lower.contains("missed") || lower.contains("behind") -> {
        buildString {
          append("### 🛡️ Sustainable Recovery Protocol\n\n")
          append("Remember: **Momentum is not fragile unless you believe it is.**\n\n")
          append("1. **Zero Guilt Rule:** A missed day is merely feedback about friction or energy, not a character flaw.\n")
          append("2. **Micro-Restart:** Do NOT try to double your workload today. Pick just ONE 15-minute quick win.\n")
          append("3. **Protect the Keystone:** Maintain your habit streak today even if it's the 2-minute version.\n")
          append("4. **Reset the Timeline:** Defer non-urgent items by 48 hours to create breathing room.")
        }
      }
      lower.contains("goal") || lower.contains("progress") || lower.contains("okr") -> {
        val topGoal = goals.firstOrNull()
        buildString {
          append("### 🎯 Goal Calibration & Trajectory\n\n")
          if (topGoal != null) {
            append("Reviewing **${topGoal.title}**:\n")
            append("• Current metric: **${topGoal.currentMetric} / ${topGoal.targetMetric} ${topGoal.metricUnit}**\n")
            append("• Suggested immediate next action: Schedule a 30-minute dedicated work block this week.\n\n")
          }
          append("**Key Heuristic:** Measure outcomes by milestone completion and consistency of deliberate inputs, rather than vague busywork.")
        }
      }
      else -> {
        buildString {
          append("### ⚡ ASCEND Executive Guidance\n\n")
          append("You currently have **${pendingTasks.size} active tasks** totaling ~**${String.format("%.1f", totalEstHours)} hours** of estimated work.\n\n")
          append("• **Immediate Next Step:** Choose one task with HIGH priority and run a 25-minute Focus Session.\n")
          append("• **Habit Consistency:** You have ${habits.size} tracked habits. Check off your morning habits to maintain streaks.\n")
          append("• **Focus Tip:** Eliminate friction by closing all irrelevant applications before starting.")
        }
      }
    }
  }
}
