package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.model.UserProfileEntity
import com.example.ui.components.AscendBottomNav
import com.example.ui.components.AscendTopBar
import com.example.ui.components.MoreNavigationSheet
import com.example.ui.dialogs.GoalEditDialog
import com.example.ui.dialogs.HabitEditDialog
import com.example.ui.dialogs.NoteEditDialog
import com.example.ui.dialogs.ProjectEditDialog
import com.example.ui.dialogs.TaskEditDialog
import com.example.ui.navigation.AscendDestination
import com.example.ui.screens.AIAssistantScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.FocusScreen
import com.example.ui.screens.GoalsScreen
import com.example.ui.screens.HabitsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyDayScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.theme.AscendTheme
import com.example.ui.theme.ThemeMode
import com.example.ui.theme.ascendColors
import com.example.viewmodel.AscendViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: AscendViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      val userProfile by viewModel.userProfile.collectAsState()

      val currentThemeMode = when (userProfile?.themeMode) {
        "DARK" -> ThemeMode.DARK
        "LIGHT" -> ThemeMode.LIGHT
        else -> ThemeMode.SYSTEM
      }

      val isPersian = userProfile?.language == "fa"
      val layoutDirection = if (isPersian) LayoutDirection.Rtl else LayoutDirection.Ltr

      AscendTheme(themeMode = currentThemeMode) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
          if (userProfile != null && !userProfile!!.onboardingCompleted) {
            OnboardingScreen(
              onCompleteOnboarding = { profile ->
                viewModel.updateProfile(profile)
              }
            )
          } else {
            AscendAppContent(viewModel = viewModel, isPersian = isPersian, currentTheme = currentThemeMode)
          }
        }
      }
    }
  }
}

@Composable
fun AscendAppContent(
  viewModel: AscendViewModel,
  isPersian: Boolean,
  currentTheme: ThemeMode
) {
  val colors = MaterialTheme.ascendColors

  val currentDestination by viewModel.currentDestination.collectAsState()
  val userProfile by viewModel.userProfile.collectAsState()
  val tasks by viewModel.tasks.collectAsState()
  val projects by viewModel.projects.collectAsState()
  val goals by viewModel.goals.collectAsState()
  val habits by viewModel.habits.collectAsState()
  val habitLogs by viewModel.habitLogs.collectAsState()
  val focusSessions by viewModel.focusSessions.collectAsState()
  val notes by viewModel.notes.collectAsState()
  val dailyPlan by viewModel.dailyPlan.collectAsState()

  val taskSearchQuery by viewModel.taskSearchQuery.collectAsState()
  val taskFilter by viewModel.taskFilter.collectAsState()

  val timerTotalSeconds by viewModel.timerTotalSeconds.collectAsState()
  val timerRemainingSeconds by viewModel.timerRemainingSeconds.collectAsState()
  val isTimerRunning by viewModel.isTimerRunning.collectAsState()
  val isTimerPaused by viewModel.isTimerPaused.collectAsState()
  val activeFocusTask by viewModel.activeFocusTask.collectAsState()
  val distractionCount by viewModel.distractionCount.collectAsState()

  val aiMessages by viewModel.aiMessages.collectAsState()
  val isAiLoading by viewModel.isAiLoading.collectAsState()

  val showTaskDialog by viewModel.showTaskDialog.collectAsState()
  val editingTask by viewModel.editingTask.collectAsState()

  val showGoalDialog by viewModel.showGoalDialog.collectAsState()
  val editingGoal by viewModel.editingGoal.collectAsState()

  val showHabitDialog by viewModel.showHabitDialog.collectAsState()
  val editingHabit by viewModel.editingHabit.collectAsState()

  val showProjectDialog by viewModel.showProjectDialog.collectAsState()
  val editingProject by viewModel.editingProject.collectAsState()

  val showNoteDialog by viewModel.showNoteDialog.collectAsState()
  val editingNote by viewModel.editingNote.collectAsState()

  val showMoreSheet by viewModel.showMoreSheet.collectAsState()

  // Hardware/gesture BackHandler
  BackHandler(enabled = currentDestination != AscendDestination.HOME) {
    viewModel.navigateBack()
  }

  Scaffold(
    topBar = {
      AscendTopBar(
        destination = currentDestination,
        userProfile = userProfile,
        currentTheme = currentTheme,
        isPersian = isPersian,
        onToggleTheme = {
          val next = when (currentTheme) {
            ThemeMode.DARK -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.DARK
            ThemeMode.SYSTEM -> ThemeMode.DARK
          }
          userProfile?.let { viewModel.updateProfile(it.copy(themeMode = next.name)) }
        },
        onToggleLanguage = {
          val nextLang = if (isPersian) "en" else "fa"
          userProfile?.let { viewModel.updateProfile(it.copy(language = nextLang)) }
        },
        onLevelClick = {
          viewModel.navigateTo(AscendDestination.PROGRESS)
        }
      )
    },
    bottomBar = {
      AscendBottomNav(
        currentDestination = currentDestination,
        isPersian = isPersian,
        onNavigate = { dest -> viewModel.navigateTo(dest) },
        onOpenMore = { viewModel.showMoreSheet.value = true }
      )
    },
    containerColor = colors.mainBackground
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(colors.mainBackground)
    ) {
      when (currentDestination) {
        AscendDestination.HOME -> HomeScreen(
          userProfile = userProfile,
          tasks = tasks,
          habits = habits,
          habitLogs = habitLogs,
          goals = goals,
          focusSessions = focusSessions,
          todayDate = viewModel.todayDate,
          isPersian = isPersian,
          onNavigate = { dest -> viewModel.navigateTo(dest) },
          onToggleTask = { task -> viewModel.toggleTaskCompletion(task) },
          onToggleHabit = { habitId, isDone -> viewModel.toggleHabitToday(habitId, isDone) },
          onQuickAddTask = {
            viewModel.editingTask.value = null
            viewModel.showTaskDialog.value = true
          },
          onStartFocus = {
            viewModel.navigateTo(AscendDestination.FOCUS)
            viewModel.startTimer()
          }
        )

        AscendDestination.MY_DAY -> MyDayScreen(
          dailyPlan = dailyPlan,
          tasks = tasks,
          userProfile = userProfile,
          todayDate = viewModel.todayDate,
          isPersian = isPersian,
          onSavePlan = { plan -> viewModel.savePlan(plan) },
          onToggleTask = { task -> viewModel.toggleTaskCompletion(task) },
          onStartFocus = { task ->
            viewModel.setFocusTask(task)
            viewModel.navigateTo(AscendDestination.FOCUS)
            viewModel.startTimer()
          },
          onAddTask = {
            viewModel.editingTask.value = null
            viewModel.showTaskDialog.value = true
          }
        )

        AscendDestination.TASKS -> TasksScreen(
          tasks = tasks,
          projects = projects,
          searchQuery = taskSearchQuery,
          currentFilter = taskFilter,
          todayDate = viewModel.todayDate,
          isPersian = isPersian,
          onSearchChange = { q -> viewModel.setTaskSearchQuery(q) },
          onFilterChange = { f -> viewModel.setTaskFilter(f) },
          onToggleTask = { task -> viewModel.toggleTaskCompletion(task) },
          onEditTask = { task ->
            viewModel.editingTask.value = task
            viewModel.showTaskDialog.value = true
          },
          onDeleteTask = { task -> viewModel.deleteTask(task) },
          onStartFocus = { task ->
            viewModel.setFocusTask(task)
            viewModel.navigateTo(AscendDestination.FOCUS)
            viewModel.startTimer()
          },
          onAddTask = {
            viewModel.editingTask.value = null
            viewModel.showTaskDialog.value = true
          }
        )

        AscendDestination.FOCUS -> FocusScreen(
          timerTotalSeconds = timerTotalSeconds,
          timerRemainingSeconds = timerRemainingSeconds,
          isRunning = isTimerRunning,
          isPaused = isTimerPaused,
          activeTask = activeFocusTask,
          distractionCount = distractionCount,
          recentSessions = focusSessions,
          isPersian = isPersian,
          onSetDuration = { mins -> viewModel.setTimerDuration(mins) },
          onStart = { viewModel.startTimer() },
          onPause = { viewModel.pauseTimer() },
          onReset = { viewModel.resetTimer() },
          onComplete = { viewModel.completeTimer() },
          onLogDistraction = { viewModel.logDistraction() }
        )

        AscendDestination.CALENDAR -> CalendarScreen(
          tasks = tasks,
          focusSessions = focusSessions,
          todayDate = viewModel.todayDate,
          isPersian = isPersian,
          onStartFocus = { task ->
            viewModel.setFocusTask(task)
            viewModel.navigateTo(AscendDestination.FOCUS)
            viewModel.startTimer()
          }
        )

        AscendDestination.GOALS -> GoalsScreen(
          goals = goals,
          isPersian = isPersian,
          onAddGoal = {
            viewModel.editingGoal.value = null
            viewModel.showGoalDialog.value = true
          },
          onEditGoal = { goal ->
            viewModel.editingGoal.value = goal
            viewModel.showGoalDialog.value = true
          },
          onDeleteGoal = { goal -> viewModel.deleteGoal(goal) },
          onUpdateProgress = { goal, p -> viewModel.updateGoalProgress(goal, p) }
        )

        AscendDestination.HABITS -> HabitsScreen(
          habits = habits,
          habitLogs = habitLogs,
          todayDate = viewModel.todayDate,
          isPersian = isPersian,
          onToggleHabit = { habitId, isDone -> viewModel.toggleHabitToday(habitId, isDone) },
          onAddHabit = {
            viewModel.editingHabit.value = null
            viewModel.showHabitDialog.value = true
          },
          onEditHabit = { habit ->
            viewModel.editingHabit.value = habit
            viewModel.showHabitDialog.value = true
          },
          onDeleteHabit = { habit -> viewModel.deleteHabit(habit) }
        )

        AscendDestination.PROGRESS -> ProgressScreen(
          userProfile = userProfile,
          tasks = tasks,
          habits = habits,
          habitLogs = habitLogs,
          goals = goals,
          focusSessions = focusSessions,
          isPersian = isPersian
        )

        AscendDestination.AI_ASSISTANT -> AIAssistantScreen(
          messages = aiMessages,
          isLoading = isAiLoading,
          isPersian = isPersian,
          onSendMessage = { prompt -> viewModel.sendAiPrompt(prompt) }
        )

        AscendDestination.NOTES -> NotesScreen(
          notes = notes,
          isPersian = isPersian,
          onAddNote = {
            viewModel.editingNote.value = null
            viewModel.showNoteDialog.value = true
          },
          onEditNote = { note ->
            viewModel.editingNote.value = note
            viewModel.showNoteDialog.value = true
          },
          onDeleteNote = { note -> viewModel.deleteNote(note) }
        )

        AscendDestination.PROJECTS -> ProjectsScreen(
          projects = projects,
          tasks = tasks,
          isPersian = isPersian,
          onAddProject = {
            viewModel.editingProject.value = null
            viewModel.showProjectDialog.value = true
          },
          onEditProject = { project ->
            viewModel.editingProject.value = project
            viewModel.showProjectDialog.value = true
          },
          onDeleteProject = { project -> viewModel.deleteProject(project) }
        )

        AscendDestination.SETTINGS -> SettingsScreen(
          userProfile = userProfile,
          currentTheme = currentTheme,
          isPersian = isPersian,
          onUpdateTheme = { mode ->
            userProfile?.let { viewModel.updateProfile(it.copy(themeMode = mode.name)) }
          },
          onUpdateLanguage = { lang ->
            userProfile?.let { viewModel.updateProfile(it.copy(language = lang)) }
          },
          onUpdateProfile = { p -> viewModel.updateProfile(p) },
          onResetSampleData = { viewModel.resetToSampleData() },
          onExportJson = { viewModel.exportDataAsJson() }
        )
      }
    }

    // Secondary navigation drawer/sheet
    MoreNavigationSheet(
      isOpen = showMoreSheet,
      currentDestination = currentDestination,
      isPersian = isPersian,
      onDismiss = { viewModel.showMoreSheet.value = false },
      onNavigate = { dest -> viewModel.navigateTo(dest) }
    )

    // Dialogs
    if (showTaskDialog) {
      TaskEditDialog(
        task = editingTask,
        projects = projects,
        todayDate = viewModel.todayDate,
        isPersian = isPersian,
        onDismiss = { viewModel.showTaskDialog.value = false },
        onSave = { task ->
          viewModel.saveTask(task)
          viewModel.showTaskDialog.value = false
        }
      )
    }

    if (showHabitDialog) {
      HabitEditDialog(
        habit = editingHabit,
        isPersian = isPersian,
        onDismiss = { viewModel.showHabitDialog.value = false },
        onSave = { habit ->
          viewModel.saveHabit(habit)
          viewModel.showHabitDialog.value = false
        }
      )
    }

    if (showGoalDialog) {
      GoalEditDialog(
        goal = editingGoal,
        isPersian = isPersian,
        onDismiss = { viewModel.showGoalDialog.value = false },
        onSave = { goal ->
          viewModel.saveGoal(goal)
          viewModel.showGoalDialog.value = false
        }
      )
    }

    if (showProjectDialog) {
      ProjectEditDialog(
        project = editingProject,
        isPersian = isPersian,
        onDismiss = { viewModel.showProjectDialog.value = false },
        onSave = { project ->
          viewModel.saveProject(project)
          viewModel.showProjectDialog.value = false
        }
      )
    }

    if (showNoteDialog) {
      NoteEditDialog(
        note = editingNote,
        isPersian = isPersian,
        onDismiss = { viewModel.showNoteDialog.value = false },
        onSave = { note ->
          viewModel.saveNote(note)
          viewModel.showNoteDialog.value = false
        }
      )
    }
  }
}
