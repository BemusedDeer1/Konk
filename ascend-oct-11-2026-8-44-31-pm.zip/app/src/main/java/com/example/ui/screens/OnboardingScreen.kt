package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfileEntity
import com.example.ui.theme.ascendColors

@Composable
fun OnboardingScreen(
  onCompleteOnboarding: (UserProfileEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  var step by remember { mutableIntStateOf(1) }
  var name by remember { mutableStateOf("Alex") }
  var selectedLanguage by remember { mutableStateOf("en") }
  var focusDuration by remember { mutableIntStateOf(25) }
  var dailyTargetHours by remember { mutableIntStateOf(6) }

  val isPersian = selectedLanguage == "fa"

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(colors.mainBackground)
      .verticalScroll(rememberScrollState())
      .padding(24.dp)
      .testTag("onboarding_screen"),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    // Brand Crest
    Box(
      modifier = Modifier
        .size(64.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(colors.accent),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.Bolt,
        contentDescription = "Ascend Emblem",
        tint = colors.mainBackground,
        modifier = Modifier.size(36.dp)
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "ASCEND",
      style = MaterialTheme.typography.labelMedium,
      fontWeight = FontWeight.Bold,
      color = colors.accent,
      letterSpacing = 2.sp
    )

    Text(
      text = if (isPersian) "روز خود را طراحی کنید. آینده‌تان را بسازید." else "Design your days. Build your future.",
      style = MaterialTheme.typography.bodySmall,
      color = colors.secondaryText
    )

    Spacer(modifier = Modifier.height(28.dp))

    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        when (step) {
          1 -> {
            Text(
              text = if (isPersian) "نام شما چیست؟" else "What is your preferred name?",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "صعود سیستم عامل شخصی برای رشد و بهره‌وری پایدار شماست." else "Ascend is your personal operating system for relentless life progression.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
              value = name,
              onValueChange = { name = it },
              label = { Text(if (isPersian) "نام شما" else "Your Name") },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth().testTag("onboarding_name_input"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.accent,
                unfocusedBorderColor = colors.borderColor
              )
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
              text = if (isPersian) "زبان ترجیحی:" else "Preferred Language:",
              style = MaterialTheme.typography.labelSmall,
              color = colors.secondaryText
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (selectedLanguage == "en") colors.accent else colors.elevatedSurface,
                modifier = Modifier
                  .weight(1f)
                  .clickable { selectedLanguage = "en" }
              ) {
                Box(modifier = Modifier.padding(10.dp), contentAlignment = Alignment.Center) {
                  Text(
                    text = "English",
                    fontWeight = FontWeight.Bold,
                    color = if (selectedLanguage == "en") colors.mainBackground else colors.primaryText
                  )
                }
              }

              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (selectedLanguage == "fa") colors.accent else colors.elevatedSurface,
                modifier = Modifier
                  .weight(1f)
                  .clickable { selectedLanguage = "fa" }
              ) {
                Box(modifier = Modifier.padding(10.dp), contentAlignment = Alignment.Center) {
                  Text(
                    text = "فارسی (RTL)",
                    fontWeight = FontWeight.Bold,
                    color = if (selectedLanguage == "fa") colors.mainBackground else colors.primaryText
                  )
                }
              }
            }
          }

          2 -> {
            Text(
              text = if (isPersian) "ریتم تمرکز شما چیست؟" else "Configure Your Flow Style",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "مدت پیش‌فرض هر نشست تمرکز عمیق را انتخاب کنید." else "Select your standard deep-work block duration.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )

            Spacer(modifier = Modifier.height(16.dp))

            listOf(15, 25, 50).forEach { mins ->
              val isSelected = focusDuration == mins
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) colors.accent else colors.elevatedSurface,
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp)
                  .clickable { focusDuration = mins }
              ) {
                Row(
                  modifier = Modifier.padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "$mins Minutes Block",
                    fontWeight = FontWeight.SemiBold,
                    color = if (isSelected) colors.mainBackground else colors.primaryText
                  )
                  if (isSelected) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = colors.mainBackground)
                  }
                }
              }
            }
          }

          3 -> {
            Text(
              text = if (isPersian) "ظرفیت روزانه هدف" else "Daily Target Capacity",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "چند ساعت در روز برای کار عمیق و اهداف در نظر دارید؟" else "Realistic hours of focused execution per day.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )

            Spacer(modifier = Modifier.height(16.dp))

            listOf(4, 6, 8).forEach { hrs ->
              val isSelected = dailyTargetHours == hrs
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) colors.accent else colors.elevatedSurface,
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp)
                  .clickable { dailyTargetHours = hrs }
              ) {
                Row(
                  modifier = Modifier.padding(14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "$hrs Hours / day",
                    fontWeight = FontWeight.SemiBold,
                    color = if (isSelected) colors.mainBackground else colors.primaryText
                  )
                  if (isSelected) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = colors.mainBackground)
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Next / Finish Button
        Button(
          onClick = {
            if (step < 3) {
              step += 1
            } else {
              onCompleteOnboarding(
                UserProfileEntity(
                  id = 1,
                  name = if (name.isBlank()) "Explorer" else name,
                  language = selectedLanguage,
                  focusMinutesDefault = focusDuration,
                  dailyTargetHours = dailyTargetHours,
                  onboardingCompleted = true,
                  xpPoints = 150,
                  level = 1
                )
              )
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().testTag("onboarding_continue_btn")
        ) {
          Text(if (step < 3) (if (isPersian) "ادامه" else "Next Step") else (if (isPersian) "ورود به صعود" else "Enter ASCEND"))
          Spacer(modifier = Modifier.width(6.dp))
          Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
        }

        if (step < 3) {
          Spacer(modifier = Modifier.height(6.dp))
          TextButton(
            onClick = {
              onCompleteOnboarding(
                UserProfileEntity(
                  id = 1,
                  name = if (name.isBlank()) "Explorer" else name,
                  language = selectedLanguage,
                  focusMinutesDefault = focusDuration,
                  dailyTargetHours = dailyTargetHours,
                  onboardingCompleted = true,
                  xpPoints = 120,
                  level = 1
                )
              )
            },
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(if (isPersian) "رد کردن و ورود با مقادیر پیش‌فرض" else "Skip to Dashboard", color = colors.secondaryText)
          }
        }
      }
    }
  }
}
