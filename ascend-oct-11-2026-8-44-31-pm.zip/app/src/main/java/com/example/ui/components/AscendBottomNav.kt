package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.navigation.AscendDestination
import com.example.ui.theme.ascendColors

@Composable
fun AscendBottomNav(
  currentDestination: AscendDestination,
  isPersian: Boolean,
  onNavigate: (AscendDestination) -> Unit,
  onOpenMore: () -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  val primaryTabs = listOf(
    AscendDestination.HOME,
    AscendDestination.MY_DAY,
    AscendDestination.TASKS,
    AscendDestination.FOCUS
  )

  val isMoreSelected = !primaryTabs.contains(currentDestination)

  NavigationBar(
    modifier = modifier
      .windowInsetsPadding(WindowInsets.navigationBars)
      .testTag("ascend_bottom_navigation"),
    containerColor = colors.secondaryBackground,
    tonalElevation = 6.dp
  ) {
    primaryTabs.forEach { destination ->
      val isSelected = currentDestination == destination

      NavigationBarItem(
        selected = isSelected,
        onClick = { onNavigate(destination) },
        icon = {
          Icon(
            imageVector = destination.icon,
            contentDescription = if (isPersian) destination.titleFa else destination.titleEn
          )
        },
        label = {
          Text(
            text = if (isPersian) destination.titleFa else destination.titleEn,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
          )
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = colors.mainBackground,
          selectedTextColor = colors.accent,
          indicatorColor = colors.accent,
          unselectedIconColor = colors.secondaryText,
          unselectedTextColor = colors.secondaryText
        ),
        modifier = Modifier.testTag("nav_${destination.route}")
      )
    }

    // More item
    NavigationBarItem(
      selected = isMoreSelected,
      onClick = onOpenMore,
      icon = {
        Icon(
          imageVector = Icons.Default.MoreHoriz,
          contentDescription = if (isPersian) "بیشتر" else "More"
        )
      },
      label = {
        Text(
          text = if (isPersian) "بیشتر" else "More",
          fontWeight = if (isMoreSelected) FontWeight.Bold else FontWeight.Normal
        )
      },
      colors = NavigationBarItemDefaults.colors(
        selectedIconColor = colors.mainBackground,
        selectedTextColor = colors.accent,
        indicatorColor = colors.accent,
        unselectedIconColor = colors.secondaryText,
        unselectedTextColor = colors.secondaryText
      ),
      modifier = Modifier.testTag("nav_more")
    )
  }
}
