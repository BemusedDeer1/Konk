package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DailyPlanEntity
import com.example.model.TaskEntity
import com.example.model.UserProfileEntity
import com.example.ui.theme.ascendColors

@Composable
fun MyDayScreen(
  dailyPlan: DailyPlanEntity?,
  tasks: List<TaskEntity>,
  userProfile: UserProfileEntity?,
  todayDate: String,
  isPersian: Boolean,
  onSavePlan: (DailyPlanEntity) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onStartFocus: (TaskEntity) -> Unit,
  onAddTask: () -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  var mainPriority by remember(dailyPlan) { mutableStateOf(dailyPlan?.mainPriority ?: "") }
  var outcome1 by remember(dailyPlan) { mutableStateOf(dailyPlan?.outcome1 ?: "") }
  var outcome2 by remember(dailyPlan) { mutableStateOf(dailyPlan?.outcome2 ?: "") }
  var outcome3 by remember(dailyPlan) { mutableStateOf(dailyPlan?.outcome3 ?: "") }
  var reflectionNotes by remember(dailyPlan) { mutableStateOf(dailyPlan?.reflectionNotes ?: "") }
  var dayRating by remember(dailyPlan) { mutableIntStateOf(dailyPlan?.rating ?: 5) }

  val targetWorkHours = userProfile?.dailyTargetHours ?: 6
  val todayTasks = tasks.filter { it.scheduledDate == todayDate || it.dueDate == todayDate || !it.isCompleted }
  val totalEstimatedMinutes = todayTasks.sumOf { it.estimatedMinutes }
  val totalEstimatedHours = totalEstimatedMinutes / 60.0

  val isOverloaded = totalEstimatedHours > targetWorkHours

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
      .testTag("my_day_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Header & Capacity Indicator
    Card(
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = if (isPersian) "طراحی برنامه امروز" else "Intelligent Day Architecture",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = todayDate,
              style = MaterialTheme.typography.labelSmall,
              color = colors.secondaryText
            )
          }

          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (isOverloaded) colors.error.copy(alpha = 0.2f) else colors.positive.copy(alpha = 0.2f)
          ) {
            Text(
              text = "${String.format("%.1f", totalEstimatedHours)}h / ${targetWorkHours}h",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = if (isOverloaded) colors.error else colors.positive,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }

        if (isOverloaded) {
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(colors.error.copy(alpha = 0.15f))
              .padding(8.dp)
          ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = colors.error, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isPersian) "هشدار تراکم: حجم کار فراتر از توان مجاز است. کارهای غیراضطراری را به فردا موکول کنید." else "Overload Warning: Workload exceeds target capacity. Defer lower-priority tasks.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.error
            )
          }
        }
      }
    }

    // 2. The One Anchor Priority
    Card(
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "⭐ اولویت اصلی امروز (The One Thing)" else "⭐ The Single Anchor Priority",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = colors.accent
        )
        Text(
          text = if (isPersian) "کاری که اگر فقط آن انجام شود، امروز موفقیت‌آمیز بوده است" else "If only this gets done, the day is a success",
          style = MaterialTheme.typography.bodySmall,
          color = colors.secondaryText
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = mainPriority,
          onValueChange = { mainPriority = it },
          placeholder = { Text(if (isPersian) "مثال: تکمیل بخش اصلی پروژه و تست نهایی" else "e.g., Deliver core architecture milestone") },
          modifier = Modifier.fillMaxWidth().testTag("input_main_priority"),
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.accent,
            unfocusedBorderColor = colors.borderColor
          )
        )
      }
    }

    // 3. Top 3 Outcomes
    Card(
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "🎯 ۳ دستاورد کلیدی امروز" else "🎯 Top 3 Outcomes",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutcomeField(value = outcome1, onChange = { outcome1 = it }, index = 1, placeholder = if (isPersian) "دستاورد ۱" else "Outcome 1")
        Spacer(modifier = Modifier.height(8.dp))
        OutcomeField(value = outcome2, onChange = { outcome2 = it }, index = 2, placeholder = if (isPersian) "دستاورد ۲" else "Outcome 2")
        Spacer(modifier = Modifier.height(8.dp))
        OutcomeField(value = outcome3, onChange = { outcome3 = it }, index = 3, placeholder = if (isPersian) "دستاورد ۳" else "Outcome 3")
      }
    }

    // 4. Scheduled Activities Checklist
    Card(
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isPersian) "فعالیت‌های زمان‌بندی‌شده" else "Scheduled Timeline",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = colors.primaryText
          )
          Button(
            onClick = onAddTask,
            colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("myday_add_task_btn")
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isPersian) "افزودن" else "Add Task", fontSize = 12.sp)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (todayTasks.isEmpty()) {
          Text(
            text = if (isPersian) "هنوز وظیفه‌ای برای امروز ثبت نشده است." else "No tasks scheduled for today.",
            style = MaterialTheme.typography.bodySmall,
            color = colors.secondaryText
          )
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            todayTasks.forEach { task ->
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = colors.elevatedSurface,
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Checkbox(
                    checked = task.isCompleted,
                    onCheckedChange = { onToggleTask(task) },
                    colors = CheckboxDefaults.colors(checkedColor = colors.positive)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = task.title,
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.Medium,
                      color = colors.primaryText
                    )
                    Text(
                      text = "~${task.estimatedMinutes}m | ${task.priority}",
                      style = MaterialTheme.typography.labelSmall,
                      color = colors.secondaryText
                    )
                  }
                  if (!task.isCompleted) {
                    Button(
                      onClick = { onStartFocus(task) },
                      colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                      shape = RoundedCornerShape(8.dp)
                    ) {
                      Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // 5. Evening Reflection & Rating
    Card(
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "🌙 بازتاب و ارزیابی پایان روز" else "🌙 End of Day Reflection",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )
        Text(
          text = if (isPersian) "چه چیزی خوب پیش رفت؟ چه اصطکاکی وجود داشت؟" else "What created flow? What caused friction?",
          style = MaterialTheme.typography.bodySmall,
          color = colors.secondaryText
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Star rating
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          (1..5).forEach { star ->
            Icon(
              imageVector = Icons.Default.Star,
              contentDescription = "Rating $star",
              tint = if (star <= dayRating) colors.warning else colors.borderColor,
              modifier = Modifier
                .size(28.dp)
                .clickable { dayRating = star }
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = reflectionNotes,
          onValueChange = { reflectionNotes = it },
          placeholder = { Text(if (isPersian) "نکات و بازتاب شما برای فردای بهتر..." else "Wins, friction points, or lesson learned...") },
          modifier = Modifier.fillMaxWidth().height(100.dp).testTag("input_reflection_notes"),
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.accent,
            unfocusedBorderColor = colors.borderColor
          )
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = {
            onSavePlan(
              DailyPlanEntity(
                dateString = todayDate,
                mainPriority = mainPriority,
                outcome1 = outcome1,
                outcome2 = outcome2,
                outcome3 = outcome3,
                reflectionNotes = reflectionNotes,
                rating = dayRating
              )
            )
          },
          colors = ButtonDefaults.buttonColors(containerColor = colors.positive),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth().testTag("save_daily_plan_btn")
        ) {
          Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isPersian) "ذخیره برنامه و بازتاب روز" else "Save Daily Architecture")
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}

@Composable
private fun OutcomeField(
  value: String,
  onChange: (String) -> Unit,
  index: Int,
  placeholder: String
) {
  val colors = MaterialTheme.ascendColors
  OutlinedTextField(
    value = value,
    onValueChange = onChange,
    placeholder = { Text(placeholder) },
    prefix = { Text("$index. ", color = colors.accent, fontWeight = FontWeight.Bold) },
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(10.dp),
    colors = OutlinedTextFieldDefaults.colors(
      focusedBorderColor = colors.accent,
      unfocusedBorderColor = colors.borderColor
    )
  )
}
