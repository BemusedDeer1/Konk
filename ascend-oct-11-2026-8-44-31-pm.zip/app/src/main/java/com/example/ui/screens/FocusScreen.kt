package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FocusSessionEntity
import com.example.model.TaskEntity
import com.example.ui.theme.ascendColors

@Composable
fun FocusScreen(
  timerTotalSeconds: Int,
  timerRemainingSeconds: Int,
  isRunning: Boolean,
  isPaused: Boolean,
  activeTask: TaskEntity?,
  distractionCount: Int,
  recentSessions: List<FocusSessionEntity>,
  isPersian: Boolean,
  onSetDuration: (Int) -> Unit,
  onStart: () -> Unit,
  onPause: () -> Unit,
  onReset: () -> Unit,
  onComplete: () -> Unit,
  onLogDistraction: () -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  val minutes = timerRemainingSeconds / 60
  val seconds = timerRemainingSeconds % 60
  val timeFormatted = String.format("%02d:%02d", minutes, seconds)

  val progress = if (timerTotalSeconds > 0) {
    (timerRemainingSeconds.toFloat() / timerTotalSeconds.toFloat()).coerceIn(0f, 1f)
  } else 1f

  val totalFocusMinutesToday = recentSessions.sumOf { it.durationMinutes }

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
      .testTag("focus_screen"),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(18.dp)
  ) {
    // 1. Linked Task Indicator
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Text(
          text = if (isPersian) "هدف این نشست تمرکز:" else "Focus Objective:",
          style = MaterialTheme.typography.labelSmall,
          color = colors.secondaryText
        )
        Text(
          text = activeTask?.title ?: (if (isPersian) "بلوک عمومی کار عمیق و بدون حواس‌پرتی" else "General Deep Work & Flow Block"),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText,
          maxLines = 1
        )
      }
    }

    // 2. Preset Duration Buttons (only when not running)
    if (!isRunning) {
      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        PresetButton(label = "15m", onClick = { onSetDuration(15) }, isSelected = timerTotalSeconds == 15 * 60, modifier = Modifier.weight(1f))
        PresetButton(label = "25m", onClick = { onSetDuration(25) }, isSelected = timerTotalSeconds == 25 * 60, modifier = Modifier.weight(1f))
        PresetButton(label = "50m", onClick = { onSetDuration(50) }, isSelected = timerTotalSeconds == 50 * 60, modifier = Modifier.weight(1f))
        PresetButton(label = "5m Rest", onClick = { onSetDuration(5) }, isSelected = timerTotalSeconds == 5 * 60, modifier = Modifier.weight(1f))
      }
    }

    // 3. Circular Timer Visualization
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .size(260.dp)
        .padding(16.dp)
    ) {
      val trackColor = colors.cardSurface
      val strokeColor = colors.accent

      Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 14.dp.toPx()
        // Background track
        drawCircle(
          color = trackColor,
          style = Stroke(width = strokeWidth)
        )
        // Progress Arc
        drawArc(
          color = strokeColor,
          startAngle = -90f,
          sweepAngle = progress * 360f,
          useCenter = false,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
      }

      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = timeFormatted,
          fontSize = 44.sp,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText,
          letterSpacing = 1.sp
        )
        Text(
          text = when {
            isRunning && !isPaused -> if (isPersian) "در حال تمرکز عمیق..." else "Deep Focus Mode"
            isPaused -> if (isPersian) "متوقف شده" else "Paused"
            else -> if (isPersian) "آماده شروع" else "Ready to Ascend"
          },
          style = MaterialTheme.typography.bodySmall,
          color = if (isRunning && !isPaused) colors.positive else colors.secondaryText
        )
      }
    }

    // 4. Timer Controls
    Row(
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (!isRunning || isPaused) {
        Button(
          onClick = onStart,
          colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.height(48.dp).testTag("timer_start_btn")
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isPaused) (if (isPersian) "ادامه" else "Resume") else (if (isPersian) "شروع تمرکز" else "Start Session"))
        }
      } else {
        Button(
          onClick = onPause,
          colors = ButtonDefaults.buttonColors(containerColor = colors.warning),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.height(48.dp).testTag("timer_pause_btn")
        ) {
          Icon(Icons.Default.Pause, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isPersian) "مکث" else "Pause")
        }
      }

      if (isRunning) {
        Button(
          onClick = onComplete,
          colors = ButtonDefaults.buttonColors(containerColor = colors.positive),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.height(48.dp).testTag("timer_complete_btn")
        ) {
          Icon(Icons.Default.Check, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text(if (isPersian) "پایان و ثبت" else "Finish")
        }

        OutlinedButton(
          onClick = onReset,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.height(48.dp).testTag("timer_reset_btn")
        ) {
          Icon(Icons.Default.Refresh, contentDescription = null)
        }
      }
    }

    // 5. Distraction Logger
    if (isRunning) {
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = colors.cardSurface,
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .clickable { onLogDistraction() }
          .testTag("log_distraction_btn")
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = colors.warning)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = if (isPersian) "ثبت حواس‌پرتی ذهنی یا خارجی" else "Log Distraction Urge",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Medium,
                color = colors.primaryText
              )
              Text(
                text = if (isPersian) "روی این دکمه کلیک کنید و سریع به کار بازگردید" else "Acknowledge the impulse and return to flow",
                style = MaterialTheme.typography.bodySmall,
                color = colors.secondaryText
              )
            }
          }
          Surface(
            shape = CircleShape,
            color = colors.elevatedSurface
          ) {
            Text(
              text = "$distractionCount",
              fontWeight = FontWeight.Bold,
              color = colors.warning,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
          }
        }
      }
    }

    // 6. Focus Statistics Summary
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = if (isPersian) "مجموع تمرکز امروز" else "Today's Deep Work",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = colors.primaryText
          )
          Text(
            text = "${totalFocusMinutesToday} mins",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = colors.positive
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (recentSessions.isEmpty()) {
          Text(
            text = if (isPersian) "هنوز نشست تمرکزی تکمیل نشده است." else "No sessions completed today yet.",
            style = MaterialTheme.typography.bodySmall,
            color = colors.secondaryText
          )
        } else {
          recentSessions.take(3).forEach { session ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = session.title,
                style = MaterialTheme.typography.bodySmall,
                color = colors.primaryText,
                maxLines = 1
              )
              Text(
                text = "+${session.durationMinutes}m",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = colors.accent
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}

@Composable
private fun PresetButton(
  label: String,
  onClick: () -> Unit,
  isSelected: Boolean,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = if (isSelected) colors.accent else colors.cardSurface,
    border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, colors.borderColor) else null,
    modifier = modifier
      .clip(RoundedCornerShape(10.dp))
      .clickable { onClick() }
  ) {
    Box(
      modifier = Modifier.padding(vertical = 10.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = if (isSelected) colors.mainBackground else colors.primaryText
      )
    }
  }
}
