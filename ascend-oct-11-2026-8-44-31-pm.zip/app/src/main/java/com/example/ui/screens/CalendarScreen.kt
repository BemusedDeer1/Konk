package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FocusSessionEntity
import com.example.model.TaskEntity
import com.example.ui.theme.ascendColors

@Composable
fun CalendarScreen(
  tasks: List<TaskEntity>,
  focusSessions: List<FocusSessionEntity>,
  todayDate: String,
  isPersian: Boolean,
  onStartFocus: (TaskEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  var selectedView by remember { mutableStateOf("DAY") } // "DAY" or "AGENDA"

  val scheduledTasks = tasks.filter { !it.isCompleted }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp)
      .testTag("calendar_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Top view toggle & date
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = if (isPersian) "تقویم و زمان‌بندی صعود" else "Time-Blocking Schedule",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = colors.primaryText
          )
          Text(
            text = todayDate,
            style = MaterialTheme.typography.labelSmall,
            color = colors.secondaryText
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          ViewToggleButton(
            label = if (isPersian) "امروز" else "Today",
            isSelected = selectedView == "DAY",
            onClick = { selectedView = "DAY" }
          )
          ViewToggleButton(
            label = if (isPersian) "کل تقویم" else "All Agenda",
            isSelected = selectedView == "AGENDA",
            onClick = { selectedView = "AGENDA" }
          )
        }
      }
    }

    // Time-blocking schedule
    if (selectedView == "DAY") {
      Text(
        text = if (isPersian) "بلوک‌های زمانی و ساعات روز" else "Daily Time-Block Allocation",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = colors.primaryText
      )

      val hours = listOf(
        "08:00" to "Morning Kickoff & Alignment",
        "09:00" to "Deep Work Block 1 (High Leverage)",
        "10:30" to "Active Break & Hydration",
        "11:00" to "Deep Work Block 2 (Execution)",
        "13:00" to "Lunch & Cognitive Rest",
        "14:30" to "Secondary Tasks & Communication",
        "16:30" to "Workout & Movement Session",
        "18:00" to "Reading & Knowledge Capture",
        "20:00" to "Evening Reflection & Plan Next Day"
      )

      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(hours) { (time, slotName) ->
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = colors.cardSurface,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = colors.elevatedSurface
              ) {
                Text(
                  text = time,
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = colors.accent,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }

              Spacer(modifier = Modifier.width(12.dp))

              Text(
                text = slotName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = colors.primaryText
              )
            }
          }
        }
      }
    } else {
      // Agenda list of scheduled tasks
      if (scheduledTasks.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = if (isPersian) "هیچ رویداد یا وظیفه زمان‌بندی‌شده‌ای ثبت نشده است." else "No scheduled events or deadlines.",
            style = MaterialTheme.typography.bodyMedium,
            color = colors.secondaryText
          )
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxSize()
        ) {
          items(scheduledTasks) { task ->
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.primaryText
                  )
                  Text(
                    text = "Due: ${task.dueDate ?: "Flexible"} | ${task.estimatedMinutes}m | ${task.priority}",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.secondaryText
                  )
                }

                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = colors.accent.copy(alpha = 0.15f),
                  modifier = Modifier.clickable { onStartFocus(task) }
                ) {
                  Text(
                    text = if (isPersian) "تمرکز" else "Focus",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = colors.accent,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ViewToggleButton(label: String, isSelected: Boolean, onClick: () -> Unit) {
  val colors = MaterialTheme.ascendColors
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = if (isSelected) colors.accent else colors.elevatedSurface,
    modifier = Modifier.clickable { onClick() }
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
      color = if (isSelected) colors.mainBackground else colors.primaryText,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
    )
  }
}
