package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class AscendExtraColors(
  val mainBackground: Color,
  val secondaryBackground: Color,
  val cardSurface: Color,
  val elevatedSurface: Color,
  val borderColor: Color,
  val primaryText: Color,
  val secondaryText: Color,
  val accent: Color,
  val positive: Color,
  val warning: Color,
  val error: Color
)

val LocalAscendColors = staticCompositionLocalOf {
  AscendExtraColors(
    mainBackground = DarkMainBg,
    secondaryBackground = DarkSecondaryBg,
    cardSurface = DarkCardSurface,
    elevatedSurface = DarkElevatedSurface,
    borderColor = DarkBorder,
    primaryText = DarkPrimaryText,
    secondaryText = DarkSecondaryText,
    accent = DarkAccent,
    positive = DarkPositive,
    warning = DarkWarning,
    error = DarkError
  )
}

private val DarkColorScheme = darkColorScheme(
  primary = DarkAccent,
  onPrimary = Color(0xFF0B0D12),
  primaryContainer = DarkAccentContainer,
  onPrimaryContainer = DarkPrimaryText,
  secondary = DarkPositive,
  onSecondary = Color(0xFF0B0D12),
  background = DarkMainBg,
  onBackground = DarkPrimaryText,
  surface = DarkCardSurface,
  onSurface = DarkPrimaryText,
  surfaceVariant = DarkElevatedSurface,
  onSurfaceVariant = DarkSecondaryText,
  outline = DarkBorder,
  error = DarkError,
  onError = Color.White
)

private val LightColorScheme = lightColorScheme(
  primary = LightAccent,
  onPrimary = Color.White,
  primaryContainer = LightAccentContainer,
  onPrimaryContainer = LightPrimaryText,
  secondary = LightPositive,
  onSecondary = Color.White,
  background = LightMainBg,
  onBackground = LightPrimaryText,
  surface = LightCardSurface,
  onSurface = LightPrimaryText,
  surfaceVariant = LightElevatedSurface,
  onSurfaceVariant = LightSecondaryText,
  outline = LightBorder,
  error = LightError,
  onError = Color.White
)

val MaterialTheme.ascendColors: AscendExtraColors
  @Composable
  @ReadOnlyComposable
  get() = LocalAscendColors.current

enum class ThemeMode {
  SYSTEM,
  DARK,
  LIGHT
}

@Composable
fun AscendTheme(
  themeMode: ThemeMode = ThemeMode.SYSTEM,
  content: @Composable () -> Unit
) {
  val isDark = when (themeMode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.DARK -> true
    ThemeMode.LIGHT -> false
  }

  val colorScheme: ColorScheme = if (isDark) DarkColorScheme else LightColorScheme

  val extraColors = if (isDark) {
    AscendExtraColors(
      mainBackground = DarkMainBg,
      secondaryBackground = DarkSecondaryBg,
      cardSurface = DarkCardSurface,
      elevatedSurface = DarkElevatedSurface,
      borderColor = DarkBorder,
      primaryText = DarkPrimaryText,
      secondaryText = DarkSecondaryText,
      accent = DarkAccent,
      positive = DarkPositive,
      warning = DarkWarning,
      error = DarkError
    )
  } else {
    AscendExtraColors(
      mainBackground = LightMainBg,
      secondaryBackground = LightSecondaryBg,
      cardSurface = LightCardSurface,
      elevatedSurface = LightElevatedSurface,
      borderColor = LightBorder,
      primaryText = LightPrimaryText,
      secondaryText = LightSecondaryText,
      accent = LightAccent,
      positive = LightPositive,
      warning = LightWarning,
      error = LightError
    )
  }

  CompositionLocalProvider(LocalAscendColors provides extraColors) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = Typography,
      content = content
    )
  }
}
