package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.navigation.AscendDestination
import com.example.ui.theme.ascendColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreNavigationSheet(
  isOpen: Boolean,
  currentDestination: AscendDestination,
  isPersian: Boolean,
  onDismiss: () -> Unit,
  onNavigate: (AscendDestination) -> Unit
) {
  if (!isOpen) return

  val colors = MaterialTheme.ascendColors
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  val moreDestinations = listOf(
    AscendDestination.CALENDAR,
    AscendDestination.GOALS,
    AscendDestination.HABITS,
    AscendDestination.PROGRESS,
    AscendDestination.AI_ASSISTANT,
    AscendDestination.NOTES,
    AscendDestination.PROJECTS,
    AscendDestination.SETTINGS
  )

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = colors.secondaryBackground,
    tonalElevation = 8.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 12.dp)
        .testTag("more_navigation_sheet")
    ) {
      Text(
        text = if (isPersian) "تمام بخش‌های صعود" else "Ascend Destinations",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = colors.primaryText
      )
      Text(
        text = if (isPersian) "دسترسی سریع به سیستم‌های مدیریت زندگی" else "Direct access to your personal operating system",
        style = MaterialTheme.typography.bodySmall,
        color = colors.secondaryText
      )

      Spacer(modifier = Modifier.height(16.dp))

      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(moreDestinations) { dest ->
          val isSelected = currentDestination == dest
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = if (isSelected) colors.cardSurface else colors.mainBackground,
            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, colors.accent) else null,
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .clickable {
                onNavigate(dest)
                onDismiss()
              }
              .testTag("more_dest_${dest.route}")
          ) {
            Row(
              modifier = Modifier.padding(14.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSelected) colors.accent else colors.cardSurface),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = dest.icon,
                  contentDescription = null,
                  tint = if (isSelected) colors.mainBackground else colors.accent,
                  modifier = Modifier.size(20.dp)
                )
              }

              Spacer(modifier = Modifier.width(12.dp))

              Text(
                text = if (isPersian) dest.titleFa else dest.titleEn,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) colors.accent else colors.primaryText
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(28.dp))
    }
  }
}
