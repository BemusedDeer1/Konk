package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ProjectEntity
import com.example.model.TaskEntity
import com.example.ui.theme.ascendColors

@Composable
fun ProjectsScreen(
  projects: List<ProjectEntity>,
  tasks: List<TaskEntity>,
  isPersian: Boolean,
  onAddProject: () -> Unit,
  onEditProject: (ProjectEntity) -> Unit,
  onDeleteProject: (ProjectEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddProject,
        containerColor = colors.accent,
        contentColor = colors.mainBackground,
        shape = CircleShape,
        modifier = Modifier.testTag("fab_add_project")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Project")
      }
    },
    containerColor = colors.mainBackground,
    modifier = modifier.testTag("projects_screen")
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      if (projects.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Folder,
              contentDescription = null,
              tint = colors.secondaryText,
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = if (isPersian) "پروژه‌ای تعریف نشده است" else "No Projects Found",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "برای گروه‌بندی وظایف روی + کلیک کنید." else "Tap + to bundle related tasks into an initiative.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.fillMaxSize().testTag("projects_lazy_column")
        ) {
          items(projects, key = { it.id }) { project ->
            val projectTasks = tasks.filter { it.projectId == project.id }
            val completedCount = projectTasks.count { it.isCompleted }
            val totalCount = projectTasks.size
            val progress = if (totalCount > 0) (completedCount.toFloat() / totalCount).coerceIn(0f, 1f) else 0f

            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
              elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
              modifier = Modifier.fillMaxWidth().testTag("project_card_${project.id}")
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.Top
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Surface(
                      shape = RoundedCornerShape(6.dp),
                      color = colors.accent.copy(alpha = 0.15f)
                    ) {
                      Text(
                        text = project.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.accent,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                      )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                      text = project.name,
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                      color = colors.primaryText
                    )

                    if (project.description.isNotBlank()) {
                      Text(
                        text = project.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.secondaryText
                      )
                    }
                  }

                  Row {
                    IconButton(onClick = { onEditProject(project) }, modifier = Modifier.size(32.dp)) {
                      Icon(Icons.Default.Edit, contentDescription = "Edit", tint = colors.secondaryText, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = { onDeleteProject(project) }, modifier = Modifier.size(32.dp)) {
                      Icon(Icons.Default.Delete, contentDescription = "Delete", tint = colors.error.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                    }
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "$completedCount of $totalCount tasks completed",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.secondaryText
                  )
                  Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = colors.positive
                  )
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                  progress = { progress },
                  modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                  color = colors.positive,
                  trackColor = colors.elevatedSurface
                )
              }
            }
          }
        }
      }
    }
  }
}
