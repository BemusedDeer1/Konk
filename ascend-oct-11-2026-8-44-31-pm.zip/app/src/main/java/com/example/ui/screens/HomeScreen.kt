package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FocusSessionEntity
import com.example.model.GoalEntity
import com.example.model.HabitEntity
import com.example.model.HabitLogEntity
import com.example.model.TaskEntity
import com.example.model.UserProfileEntity
import com.example.ui.navigation.AscendDestination
import com.example.ui.theme.ascendColors

@Composable
fun HomeScreen(
  userProfile: UserProfileEntity?,
  tasks: List<TaskEntity>,
  habits: List<HabitEntity>,
  habitLogs: List<HabitLogEntity>,
  goals: List<GoalEntity>,
  focusSessions: List<FocusSessionEntity>,
  todayDate: String,
  isPersian: Boolean,
  onNavigate: (AscendDestination) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onToggleHabit: (Long, Boolean) -> Unit,
  onQuickAddTask: () -> Unit,
  onStartFocus: () -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  val todayTasks = tasks.filter { it.scheduledDate == todayDate || it.dueDate == todayDate || !it.isCompleted }
  val completedTasksToday = tasks.filter { it.isCompleted }
  val pendingTasks = todayTasks.filter { !it.isCompleted }

  val loggedHabitIds = habitLogs.filter { it.dateString == todayDate }.map { it.habitId }.toSet()
  val todayFocusMinutes = focusSessions.sumOf { it.durationMinutes }

  val urgentTask = pendingTasks.firstOrNull { it.priority == "URGENT" || it.priority == "HIGH" }
    ?: pendingTasks.firstOrNull()

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp)
      .testTag("home_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Greeting & Hero Progress Card
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = if (isPersian) "درود، ${userProfile?.name ?: "کاربر عزیز"}" else "Welcome, ${userProfile?.name ?: "Seeker"}",
              style = MaterialTheme.typography.headlineSmall,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "روز خود را طراحی کنید. آینده‌تان را بسازید." else "Design your days. Build your future.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }

          // XP badge
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = colors.elevatedSurface
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${userProfile?.xpPoints ?: 0} XP",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = colors.positive
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Metrics Triad
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          MetricItem(
            label = if (isPersian) "وظایف انجام‌شده" else "Tasks Done",
            value = "${completedTasksToday.size}/${tasks.size}",
            color = colors.accent
          )
          MetricItem(
            label = if (isPersian) "عادت‌های امروز" else "Habits Kept",
            value = "${loggedHabitIds.size}/${habits.size}",
            color = colors.positive
          )
          MetricItem(
            label = if (isPersian) "زمان تمرکز" else "Focus Logged",
            value = "${todayFocusMinutes}m",
            color = colors.warning
          )
        }
      }
    }

    // 2. Dynamic Guidance: "What should I do now?"
    Card(
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = colors.secondaryBackground),
      border = androidx.compose.foundation.BorderStroke(1.dp, colors.borderColor),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = colors.accent,
            modifier = Modifier.size(18.dp)
          )
          Text(
            text = if (isPersian) "اکنون چه باید کرد؟" else "What Should I Do Now?",
            style = MaterialTheme.typography.labelLarge,
            color = colors.accent,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (urgentTask != null) {
          Text(
            text = urgentTask.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = colors.primaryText
          )
          if (urgentTask.description.isNotBlank()) {
            Text(
              text = urgentTask.description,
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText,
              maxLines = 2
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = onStartFocus,
              colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.testTag("home_start_focus_btn")
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (isPersian) "شروع ۲۵ دقیقه تمرکز" else "Start 25m Focus")
            }

            OutlinedButton(
              onClick = { onToggleTask(urgentTask) },
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.testTag("home_mark_task_done_btn")
            ) {
              Text(if (isPersian) "اتمام" else "Mark Done")
            }
          }
        } else {
          Text(
            text = if (isPersian) "تمام وظایف تعیین‌شده تکمیل شدند! اکنون می‌توانید به اهداف بلندمدت فکر کنید." else "All scheduled tasks complete! Great momentum. Plan tomorrow or review goals.",
            style = MaterialTheme.typography.bodyMedium,
            color = colors.positive
          )
        }
      }
    }

    // 3. Quick Action Row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      QuickActionButton(
        icon = Icons.Default.Add,
        label = if (isPersian) "ثبت وظیفه" else "New Task",
        onClick = onQuickAddTask,
        modifier = Modifier.weight(1f).testTag("home_quick_add_task")
      )
      QuickActionButton(
        icon = Icons.Default.Today,
        label = if (isPersian) "برنامه روز" else "My Day",
        onClick = { onNavigate(AscendDestination.MY_DAY) },
        modifier = Modifier.weight(1f).testTag("home_quick_my_day")
      )
      QuickActionButton(
        icon = Icons.Default.AutoAwesome,
        label = if (isPersian) "راهنمای AI" else "AI Guide",
        onClick = { onNavigate(AscendDestination.AI_ASSISTANT) },
        modifier = Modifier.weight(1f).testTag("home_quick_ai")
      )
    }

    // 4. Today's Key Tasks
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isPersian) "وظایف مهم امروز" else "Priority Tasks Today",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )
        Text(
          text = if (isPersian) "مشاهده همه" else "View All",
          style = MaterialTheme.typography.labelSmall,
          color = colors.accent,
          modifier = Modifier
            .clickable { onNavigate(AscendDestination.TASKS) }
            .padding(4.dp)
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      if (pendingTasks.isEmpty()) {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = colors.positive)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = if (isPersian) "هیچ وظیفه فعالی باقی نمانده است." else "No pending tasks. You are clear!",
              style = MaterialTheme.typography.bodyMedium,
              color = colors.secondaryText
            )
          }
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          pendingTasks.take(4).forEach { task ->
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = colors.cardSurface,
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Checkbox(
                  checked = task.isCompleted,
                  onCheckedChange = { onToggleTask(task) },
                  colors = CheckboxDefaults.colors(checkedColor = colors.positive),
                  modifier = Modifier.testTag("task_checkbox_${task.id}")
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium,
                    color = colors.primaryText
                  )
                  Text(
                    text = "${task.priority} • ${task.estimatedMinutes}m",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.secondaryText
                  )
                }
              }
            }
          }
        }
      }
    }

    // 5. Daily Habit Checklist
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isPersian) "بررسی عادت‌ها" else "Daily Habit Consistency",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )
        Text(
          text = if (isPersian) "مشاهده همه" else "View Habits",
          style = MaterialTheme.typography.labelSmall,
          color = colors.positive,
          modifier = Modifier
            .clickable { onNavigate(AscendDestination.HABITS) }
            .padding(4.dp)
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        habits.take(3).forEach { habit ->
          val isDoneToday = loggedHabitIds.contains(habit.id)
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = colors.cardSurface,
            modifier = Modifier
              .fillMaxWidth()
              .clickable { onToggleHabit(habit.id, !isDoneToday) }
              .testTag("home_habit_item_${habit.id}")
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (isDoneToday) colors.positive else colors.elevatedSurface),
                  contentAlignment = Alignment.Center
                ) {
                  if (isDoneToday) {
                    Icon(
                      imageVector = Icons.Default.Check,
                      contentDescription = null,
                      tint = colors.mainBackground,
                      modifier = Modifier.size(16.dp)
                    )
                  }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = habit.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium,
                    color = colors.primaryText
                  )
                  Text(
                    text = if (isPersian) "زنجیره: ${habit.streakCurrent} روز" else "Streak: ${habit.streakCurrent} days",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.secondaryText
                  )
                }
              }

              Text(
                text = if (isDoneToday) (if (isPersian) "انجام شد" else "Done") else (if (isPersian) "انجام نشده" else "Pending"),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = if (isDoneToday) colors.positive else colors.secondaryText
              )
            }
          }
        }
      }
    }

    // 6. Active Goals Highlight
    if (goals.isNotEmpty()) {
      Column {
        Text(
          text = if (isPersian) "پیشرفت در اهداف" else "Strategic Goals",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )
        Spacer(modifier = Modifier.height(8.dp))
        goals.take(2).forEach { goal ->
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = goal.title,
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.SemiBold,
                  color = colors.primaryText
                )
                Text(
                  text = "${goal.currentMetric.toInt()}/${goal.targetMetric.toInt()} ${goal.metricUnit}",
                  style = MaterialTheme.typography.labelSmall,
                  color = colors.accent
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              val progress = (goal.currentMetric / maxOf(1.0, goal.targetMetric)).toFloat().coerceIn(0f, 1f)
              LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = colors.accent,
                trackColor = colors.elevatedSurface
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}

@Composable
private fun MetricItem(label: String, value: String, color: Color) {
  val colors = MaterialTheme.ascendColors
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = value,
      style = MaterialTheme.typography.headlineSmall,
      fontWeight = FontWeight.Bold,
      color = color
    )
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = colors.secondaryText
    )
  }
}

@Composable
private fun QuickActionButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = colors.cardSurface,
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable { onClick() }
  ) {
    Row(
      modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = colors.accent,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = colors.primaryText,
        maxLines = 1
      )
    }
  }
}
