package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ProjectEntity
import com.example.model.TaskEntity
import com.example.ui.theme.ascendColors

@Composable
fun TasksScreen(
  tasks: List<TaskEntity>,
  projects: List<ProjectEntity>,
  searchQuery: String,
  currentFilter: String,
  todayDate: String,
  isPersian: Boolean,
  onSearchChange: (String) -> Unit,
  onFilterChange: (String) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onEditTask: (TaskEntity) -> Unit,
  onDeleteTask: (TaskEntity) -> Unit,
  onStartFocus: (TaskEntity) -> Unit,
  onAddTask: () -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  val projectMap = projects.associateBy { it.id }

  val filteredTasks = tasks.filter { task ->
    val matchesSearch = searchQuery.isBlank() ||
      task.title.contains(searchQuery, ignoreCase = true) ||
      task.description.contains(searchQuery, ignoreCase = true) ||
      task.tags.contains(searchQuery, ignoreCase = true)

    val matchesFilter = when (currentFilter) {
      "TODAY" -> (task.scheduledDate == todayDate || task.dueDate == todayDate) && !task.isCompleted
      "HIGH" -> (task.priority == "URGENT" || task.priority == "HIGH") && !task.isCompleted
      "COMPLETED" -> task.isCompleted
      "ACTIVE" -> !task.isCompleted
      else -> true // ALL
    }

    matchesSearch && matchesFilter
  }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddTask,
        containerColor = colors.accent,
        contentColor = colors.mainBackground,
        shape = CircleShape,
        modifier = Modifier.testTag("fab_add_task")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Task")
      }
    },
    containerColor = colors.mainBackground,
    modifier = modifier.testTag("tasks_screen")
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      // Search Bar
      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchChange,
        placeholder = { Text(if (isPersian) "جستجوی وظایف، برچسب‌ها یا پروژه‌ها..." else "Search tasks, tags, or projects...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = colors.secondaryText) },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("tasks_search_field"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = colors.accent,
          unfocusedBorderColor = colors.borderColor
        )
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Filter Chips
      val filters = listOf(
        "ALL" to (if (isPersian) "همه" else "All"),
        "ACTIVE" to (if (isPersian) "در دست اقدام" else "Active"),
        "TODAY" to (if (isPersian) "امروز" else "Today"),
        "HIGH" to (if (isPersian) "اولویت بالا" else "High Priority"),
        "COMPLETED" to (if (isPersian) "تکمیل شده" else "Completed")
      )

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(filters) { (key, label) ->
          val isSelected = currentFilter == key
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (isSelected) colors.accent else colors.cardSurface,
            border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, colors.borderColor) else null,
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .clickable { onFilterChange(key) }
              .testTag("filter_chip_$key")
          ) {
            Text(
              text = label,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) colors.mainBackground else colors.primaryText,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Task List or Empty State
      if (filteredTasks.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = colors.secondaryText,
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = if (isPersian) "وظیفه‌ای یافت نشد" else "No Tasks Found",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "برای ثبت اولین وظیفه، روی دکمه + در پایین کلیک کنید." else "Hit the + button below to capture an actionable task.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxSize().testTag("tasks_lazy_column")
        ) {
          items(filteredTasks, key = { it.id }) { task ->
            val project = task.projectId?.let { projectMap[it] }
            TaskCard(
              task = task,
              project = project,
              isPersian = isPersian,
              onToggle = { onToggleTask(task) },
              onEdit = { onEditTask(task) },
              onDelete = { onDeleteTask(task) },
              onStartFocus = { onStartFocus(task) }
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TaskCard(
  task: TaskEntity,
  project: ProjectEntity?,
  isPersian: Boolean,
  onToggle: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onStartFocus: () -> Unit
) {
  val colors = MaterialTheme.ascendColors

  val priorityColor = when (task.priority) {
    "URGENT" -> colors.error
    "HIGH" -> colors.warning
    "MEDIUM" -> colors.accent
    else -> colors.secondaryText
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier.fillMaxWidth().testTag("task_card_${task.id}")
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Checkbox(
        checked = task.isCompleted,
        onCheckedChange = { onToggle() },
        colors = CheckboxDefaults.colors(checkedColor = colors.positive),
        modifier = Modifier.testTag("task_check_${task.id}")
      )

      Spacer(modifier = Modifier.width(8.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = task.title,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.SemiBold,
          color = if (task.isCompleted) colors.secondaryText else colors.primaryText,
          textDecoration = if (task.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
        )

        if (task.description.isNotBlank()) {
          Text(
            text = task.description,
            style = MaterialTheme.typography.bodySmall,
            color = colors.secondaryText,
            maxLines = 1
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          // Priority badge
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = priorityColor.copy(alpha = 0.15f)
          ) {
            Text(
              text = task.priority,
              style = MaterialTheme.typography.labelSmall,
              color = priorityColor,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          Text(
            text = "${task.estimatedMinutes}m",
            style = MaterialTheme.typography.labelSmall,
            color = colors.secondaryText
          )

          if (project != null) {
            Text(
              text = "• ${project.name}",
              style = MaterialTheme.typography.labelSmall,
              color = colors.accent,
              maxLines = 1
            )
          }
        }
      }

      // Actions
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (!task.isCompleted) {
          IconButton(
            onClick = onStartFocus,
            modifier = Modifier.size(32.dp).testTag("task_focus_btn_${task.id}")
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Focus", tint = colors.accent, modifier = Modifier.size(18.dp))
          }
        }
        IconButton(
          onClick = onEdit,
          modifier = Modifier.size(32.dp).testTag("task_edit_btn_${task.id}")
        ) {
          Icon(Icons.Default.Edit, contentDescription = "Edit", tint = colors.secondaryText, modifier = Modifier.size(16.dp))
        }
        IconButton(
          onClick = onDelete,
          modifier = Modifier.size(32.dp).testTag("task_delete_btn_${task.id}")
        ) {
          Icon(Icons.Default.Delete, contentDescription = "Delete", tint = colors.error.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
        }
      }
    }
  }
}
