package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Today
import androidx.compose.ui.graphics.vector.ImageVector

enum class AscendDestination(
  val route: String,
  val titleEn: String,
  val titleFa: String,
  val icon: ImageVector,
  val isBottomBar: Boolean = false
) {
  HOME("home", "Home", "خانه", Icons.Default.Home, true),
  MY_DAY("my_day", "My Day", "روز من", Icons.Default.Today, true),
  TASKS("tasks", "Tasks", "وظایف", Icons.Default.CheckCircle, true),
  FOCUS("focus", "Focus", "تمرکز", Icons.Default.Timer, true),
  CALENDAR("calendar", "Calendar", "تقویم", Icons.Default.CalendarMonth, false),
  GOALS("goals", "Goals", "اهداف", Icons.Default.Flag, false),
  HABITS("habits", "Habits", "عادت‌ها", Icons.Default.Repeat, false),
  PROGRESS("progress", "Progress", "پیشرفت", Icons.Default.Insights, false),
  AI_ASSISTANT("ai_assistant", "AI Guide", "دستیار هوشمند", Icons.Default.AutoAwesome, false),
  NOTES("notes", "Notes", "یادداشت‌ها", Icons.Default.Description, false),
  PROJECTS("projects", "Projects", "پروژه‌ها", Icons.Default.Folder, false),
  SETTINGS("settings", "Settings", "تنظیمات", Icons.Default.Settings, false)
}
