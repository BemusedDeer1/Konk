package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HabitEntity
import com.example.model.HabitLogEntity
import com.example.ui.theme.ascendColors

@Composable
fun HabitsScreen(
  habits: List<HabitEntity>,
  habitLogs: List<HabitLogEntity>,
  todayDate: String,
  isPersian: Boolean,
  onToggleHabit: (Long, Boolean) -> Unit,
  onAddHabit: () -> Unit,
  onEditHabit: (HabitEntity) -> Unit,
  onDeleteHabit: (HabitEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  val loggedHabitIds = habitLogs.filter { it.dateString == todayDate }.map { it.habitId }.toSet()

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddHabit,
        containerColor = colors.positive,
        contentColor = colors.mainBackground,
        shape = CircleShape,
        modifier = Modifier.testTag("fab_add_habit")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Habit")
      }
    },
    containerColor = colors.mainBackground,
    modifier = modifier.testTag("habits_screen")
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      // Habit Wisdom Banner
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(colors.positive.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = colors.positive)
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = if (isPersian) "روان‌شناسی پیشرفت پایدار" else "Sustainable Habit Architecture",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "عادت‌ها با تکرار کوچک ساخته می‌شوند، نه با اراده بی‌نهایت. حتی نسخه ۲ دقیقه‌ای را حفظ کنید." else "Identity compounds through small daily votes. Never break the chain twice.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      if (habits.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Repeat,
              contentDescription = null,
              tint = colors.secondaryText,
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = if (isPersian) "هنوز عادتی ثبت نشده است" else "No Habits Built Yet",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "روی دکمه + کلیک کنید تا اولین عادت خود را ثبت کنید." else "Tap + to anchor your first keystone ritual.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.fillMaxSize().testTag("habits_lazy_column")
        ) {
          items(habits, key = { it.id }) { habit ->
            val isDoneToday = loggedHabitIds.contains(habit.id)
            HabitCard(
              habit = habit,
              isDoneToday = isDoneToday,
              isPersian = isPersian,
              onToggle = { onToggleHabit(habit.id, !isDoneToday) },
              onEdit = { onEditHabit(habit) },
              onDelete = { onDeleteHabit(habit) }
            )
          }
        }
      }
    }
  }
}

@Composable
private fun HabitCard(
  habit: HabitEntity,
  isDoneToday: Boolean,
  isPersian: Boolean,
  onToggle: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  val colors = MaterialTheme.ascendColors

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    modifier = Modifier.fillMaxWidth().testTag("habit_card_${habit.id}")
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Check-in Circle
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(if (isDoneToday) colors.positive else colors.elevatedSurface)
          .clickable { onToggle() }
          .testTag("habit_toggle_${habit.id}"),
        contentAlignment = Alignment.Center
      ) {
        if (isDoneToday) {
          Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Completed",
            tint = colors.mainBackground,
            modifier = Modifier.size(24.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = habit.title,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.SemiBold,
          color = colors.primaryText
        )

        if (habit.description.isNotBlank()) {
          Text(
            text = habit.description,
            style = MaterialTheme.typography.bodySmall,
            color = colors.secondaryText,
            maxLines = 1
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.LocalFireDepartment,
              contentDescription = null,
              tint = colors.warning,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
              text = "${habit.streakCurrent} d streak",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = colors.warning
            )
          }

          Text(
            text = "• Best: ${habit.streakBest}d",
            style = MaterialTheme.typography.labelSmall,
            color = colors.secondaryText
          )

          Text(
            text = "• ${habit.targetDaysPerWeek}x/wk",
            style = MaterialTheme.typography.labelSmall,
            color = colors.accent
          )
        }
      }

      Row {
        IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
          Icon(Icons.Default.Edit, contentDescription = "Edit", tint = colors.secondaryText, modifier = Modifier.size(16.dp))
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
          Icon(Icons.Default.Delete, contentDescription = "Delete", tint = colors.error.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
        }
      }
    }
  }
}
