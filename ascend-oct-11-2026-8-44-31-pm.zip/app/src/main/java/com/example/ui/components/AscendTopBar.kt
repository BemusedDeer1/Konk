package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfileEntity
import com.example.ui.navigation.AscendDestination
import com.example.ui.theme.ThemeMode
import com.example.ui.theme.ascendColors

@Composable
fun AscendTopBar(
  destination: AscendDestination,
  userProfile: UserProfileEntity?,
  currentTheme: ThemeMode,
  isPersian: Boolean,
  onToggleTheme: () -> Unit,
  onToggleLanguage: () -> Unit,
  onLevelClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  Surface(
    modifier = modifier.fillMaxWidth(),
    color = colors.mainBackground,
    tonalElevation = 2.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Brand & Screen Title
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(colors.accent),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = "Ascend Logo",
            tint = colors.mainBackground,
            modifier = Modifier.size(22.dp)
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Text(
            text = "ASCEND",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = colors.accent,
            letterSpacing = 1.5.sp
          )
          Text(
            text = if (isPersian) destination.titleFa else destination.titleEn,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = colors.primaryText
          )
        }
      }

      // Action Pills (Level / Theme / Lang)
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Level Pill
        if (userProfile != null) {
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = colors.cardSurface,
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .clickable { onLevelClick() }
              .testTag("topbar_level_pill")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Lv ${userProfile.level}",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = colors.positive
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "${userProfile.xpPoints} XP",
                style = MaterialTheme.typography.labelSmall,
                color = colors.secondaryText
              )
            }
          }
        }

        // Language toggle
        IconButton(
          onClick = onToggleLanguage,
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(colors.cardSurface)
            .testTag("toggle_language_button")
        ) {
          Icon(
            imageVector = Icons.Default.Translate,
            contentDescription = "Toggle Language",
            tint = if (isPersian) colors.positive else colors.secondaryText,
            modifier = Modifier.size(18.dp)
          )
        }

        // Theme toggle
        IconButton(
          onClick = onToggleTheme,
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(colors.cardSurface)
            .testTag("toggle_theme_button")
        ) {
          Icon(
            imageVector = if (currentTheme == ThemeMode.DARK) Icons.Default.LightMode else Icons.Default.DarkMode,
            contentDescription = "Toggle Theme",
            tint = colors.secondaryText,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}
