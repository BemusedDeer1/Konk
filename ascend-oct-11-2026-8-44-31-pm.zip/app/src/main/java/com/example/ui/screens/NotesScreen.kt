package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.NoteEntity
import com.example.ui.theme.ascendColors

@Composable
fun NotesScreen(
  notes: List<NoteEntity>,
  isPersian: Boolean,
  onAddNote: () -> Unit,
  onEditNote: (NoteEntity) -> Unit,
  onDeleteNote: (NoteEntity) -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  var searchQuery by remember { mutableStateOf("") }

  val filteredNotes = notes.filter {
    searchQuery.isBlank() ||
      it.title.contains(searchQuery, ignoreCase = true) ||
      it.content.contains(searchQuery, ignoreCase = true) ||
      it.tags.contains(searchQuery, ignoreCase = true)
  }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddNote,
        containerColor = colors.accent,
        contentColor = colors.mainBackground,
        shape = CircleShape,
        modifier = Modifier.testTag("fab_add_note")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Note")
      }
    },
    containerColor = colors.mainBackground,
    modifier = modifier.testTag("notes_screen")
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      // Search
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text(if (isPersian) "جستجوی یادداشت‌ها و برچسب‌ها..." else "Search notes, insights, tags...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = colors.secondaryText) },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("notes_search_input"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = colors.accent,
          unfocusedBorderColor = colors.borderColor
        )
      )

      Spacer(modifier = Modifier.height(14.dp))

      if (filteredNotes.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Description,
              contentDescription = null,
              tint = colors.secondaryText,
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = if (isPersian) "یادداشتی وجود ندارد" else "No Notes Recorded Yet",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "روی + کلیک کنید تا ایده یا بینش خود را ذخیره کنید." else "Hit + to capture an idea, principle, or review.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxSize().testTag("notes_lazy_column")
        ) {
          items(filteredNotes, key = { it.id }) { note ->
            Card(
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
              elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
              modifier = Modifier.fillMaxWidth().testTag("note_card_${note.id}")
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    if (note.isPinned) {
                      Icon(Icons.Default.PushPin, contentDescription = "Pinned", tint = colors.accent, modifier = Modifier.size(16.dp))
                    }
                    if (note.isFavorite) {
                      Icon(Icons.Default.Star, contentDescription = "Favorite", tint = colors.warning, modifier = Modifier.size(16.dp))
                    }
                    Text(
                      text = note.title,
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                      color = colors.primaryText
                    )
                  }

                  Row {
                    IconButton(onClick = { onEditNote(note) }, modifier = Modifier.size(32.dp)) {
                      Icon(Icons.Default.Edit, contentDescription = "Edit", tint = colors.secondaryText, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = { onDeleteNote(note) }, modifier = Modifier.size(32.dp)) {
                      Icon(Icons.Default.Delete, contentDescription = "Delete", tint = colors.error.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                    }
                  }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                  text = note.content,
                  style = MaterialTheme.typography.bodyMedium,
                  color = colors.secondaryText,
                  maxLines = 4
                )

                if (note.tags.isNotBlank()) {
                  Spacer(modifier = Modifier.height(10.dp))
                  Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    note.tags.split(",").forEach { tag ->
                      val cleanTag = tag.trim()
                      if (cleanTag.isNotBlank()) {
                        Surface(
                          shape = RoundedCornerShape(6.dp),
                          color = colors.elevatedSurface
                        ) {
                          Text(
                            text = "#$cleanTag",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.accent,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                          )
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
