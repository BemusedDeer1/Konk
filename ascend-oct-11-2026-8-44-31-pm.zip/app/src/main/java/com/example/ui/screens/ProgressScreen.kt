package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FocusSessionEntity
import com.example.model.GoalEntity
import com.example.model.HabitEntity
import com.example.model.HabitLogEntity
import com.example.model.TaskEntity
import com.example.model.UserProfileEntity
import com.example.ui.theme.ascendColors

@Composable
fun ProgressScreen(
  userProfile: UserProfileEntity?,
  tasks: List<TaskEntity>,
  habits: List<HabitEntity>,
  habitLogs: List<HabitLogEntity>,
  goals: List<GoalEntity>,
  focusSessions: List<FocusSessionEntity>,
  isPersian: Boolean,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  val totalTasks = tasks.size
  val completedTasks = tasks.count { it.isCompleted }
  val taskCompletionRate = if (totalTasks > 0) ((completedTasks.toFloat() / totalTasks) * 100).toInt() else 0

  val totalFocusMinutes = focusSessions.sumOf { it.durationMinutes }
  val totalFocusHours = String.format("%.1f", totalFocusMinutes / 60.0)

  val averageStreak = if (habits.isNotEmpty()) habits.map { it.streakCurrent }.average().toInt() else 0
  val bestStreakEver = if (habits.isNotEmpty()) habits.maxOf { it.streakBest } else 0

  val currentXp = userProfile?.xpPoints ?: 0
  val level = userProfile?.level ?: 1
  val xpInCurrentLevel = currentXp % 200
  val levelProgress = (xpInCurrentLevel / 200f).coerceIn(0f, 1f)

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
      .testTag("progress_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Level & XP Progression Card
    Card(
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(colors.accent.copy(alpha = 0.2f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = colors.accent)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = if (isPersian) "سطح $level: صعودگر پایدار" else "Level $level: Relentless Achiever",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = colors.primaryText
              )
              Text(
                text = if (isPersian) "$currentXp امتیاز کل تجربی" else "$currentXp Lifetime Experience Points",
                style = MaterialTheme.typography.bodySmall,
                color = colors.secondaryText
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "Progress to Level ${level + 1}",
            style = MaterialTheme.typography.labelSmall,
            color = colors.secondaryText
          )
          Text(
            text = "$xpInCurrentLevel / 200 XP",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = colors.accent
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        LinearProgressIndicator(
          progress = { levelProgress },
          modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
          color = colors.accent,
          trackColor = colors.elevatedSurface
        )
      }
    }

    // 2. Metrics Grid (Real recorded data)
    Text(
      text = if (isPersian) "شاخص‌های عملکرد واقعی" else "Recorded Performance Metrics",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = colors.primaryText
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      MetricCard(
        title = if (isPersian) "نرخ تکمیل وظایف" else "Task Success Rate",
        value = "$taskCompletionRate%",
        subtitle = "$completedTasks of $totalTasks completed",
        color = colors.positive,
        modifier = Modifier.weight(1f)
      )
      MetricCard(
        title = if (isPersian) "کل ساعات تمرکز" else "Deep Work Logged",
        value = "${totalFocusHours}h",
        subtitle = "${focusSessions.size} focus sessions",
        color = colors.accent,
        modifier = Modifier.weight(1f)
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      MetricCard(
        title = if (isPersian) "میانگین زنجیره" else "Average Streak",
        value = "$averageStreak days",
        subtitle = "Across all active habits",
        color = colors.warning,
        modifier = Modifier.weight(1f)
      )
      MetricCard(
        title = if (isPersian) "بهترین زنجیره" else "Personal Record",
        value = "$bestStreakEver days",
        subtitle = "Longest unbroken habit",
        color = colors.positive,
        modifier = Modifier.weight(1f)
      )
    }

    // 3. Goal Milestones Status
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "وضعیت پیشرفت در اهداف استراتژیک" else "Strategic Goals Milestone Status",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (goals.isEmpty()) {
          Text(
            text = if (isPersian) "هنوز هدفی ثبت نشده است." else "No goals recorded.",
            style = MaterialTheme.typography.bodySmall,
            color = colors.secondaryText
          )
        } else {
          goals.forEach { goal ->
            Column(modifier = Modifier.padding(vertical = 6.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = goal.title,
                  style = MaterialTheme.typography.bodyMedium,
                  color = colors.primaryText
                )
                Text(
                  text = "${goal.currentMetric.toInt()}/${goal.targetMetric.toInt()} ${goal.metricUnit}",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = colors.accent
                )
              }
              val pct = (goal.currentMetric / maxOf(1.0, goal.targetMetric)).toFloat().coerceIn(0f, 1f)
              Spacer(modifier = Modifier.height(4.dp))
              LinearProgressIndicator(
                progress = { pct },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = colors.accent,
                trackColor = colors.elevatedSurface
              )
            }
          }
        }
      }
    }

    // 4. Psychology of Sustainable Progress
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.secondaryBackground),
      border = androidx.compose.foundation.BorderStroke(1.dp, colors.borderColor),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "قانون پیشرفت بدون استرس" else "The Principle of Low-Friction Compounding",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = colors.accent
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = if (isPersian) "در صعود، آمار و ارقام برای سرزنش نیستند؛ این معیارها تنها آینه‌ای از الگوهای رفتاری شما هستند. موفقیت نتیجه ادامه دادن در روزهای معمولی است." else "Data in ASCEND is never weaponized for guilt. It is an objective reflection of system friction and energy flow. When metrics dip, reduce scope and protect recovery.",
          style = MaterialTheme.typography.bodySmall,
          color = colors.secondaryText
        )
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
  }
}

@Composable
private fun MetricCard(
  title: String,
  value: String,
  subtitle: String,
  color: androidx.compose.ui.graphics.Color,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        color = colors.secondaryText
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = color
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall,
        color = colors.secondaryText
      )
    }
  }
}
