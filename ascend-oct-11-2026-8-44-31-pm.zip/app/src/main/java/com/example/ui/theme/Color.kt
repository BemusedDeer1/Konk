package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Palette
val DarkMainBg = Color(0xFF0B0D12)
val DarkSecondaryBg = Color(0xFF11151D)
val DarkCardSurface = Color(0xFF171C26)
val DarkElevatedSurface = Color(0xFF202735)
val DarkBorder = Color(0xFF273142)
val DarkPrimaryText = Color(0xFFF4F6FB)
val DarkSecondaryText = Color(0xFFA0A9BA)
val DarkAccent = Color(0xFF8B7CFF)
val DarkAccentContainer = Color(0xFF2E2660)
val DarkPositive = Color(0xFF42D6A4)
val DarkWarning = Color(0xFFF5B942)
val DarkError = Color(0xFFFF647C)

// Light Palette
val LightMainBg = Color(0xFFF6F7FB)
val LightSecondaryBg = Color(0xFFFFFFFF)
val LightCardSurface = Color(0xFFFFFFFF)
val LightElevatedSurface = Color(0xFFF0F3FA)
val LightBorder = Color(0xFFE2E7F0)
val LightPrimaryText = Color(0xFF171A24)
val LightSecondaryText = Color(0xFF697386)
val LightAccent = Color(0xFF6655E8)
val LightAccentContainer = Color(0xFFEBE8FD)
val LightPositive = Color(0xFF14866D)
val LightWarning = Color(0xFFA66A08)
val LightError = Color(0xFFD83F5D)

// Brand Accents
val AscendPurple = Color(0xFF8B7CFF)
val AscendTeal = Color(0xFF42D6A4)
val AscendGold = Color(0xFFF5B942)
val AscendCoral = Color(0xFFFF647C)
val AscendBlue = Color(0xFF4D96FF)
val AscendRose = Color(0xFFFF75A0)
