package com.example.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.GoalEntity
import com.example.model.HabitEntity
import com.example.model.LifeArea
import com.example.model.NoteEntity
import com.example.model.ProjectEntity
import com.example.model.TaskEntity
import com.example.model.TaskPriority
import com.example.ui.theme.ascendColors

@Composable
fun TaskEditDialog(
  task: TaskEntity?,
  projects: List<ProjectEntity>,
  todayDate: String,
  isPersian: Boolean,
  onDismiss: () -> Unit,
  onSave: (TaskEntity) -> Unit
) {
  val colors = MaterialTheme.ascendColors

  var title by remember { mutableStateOf(task?.title ?: "") }
  var description by remember { mutableStateOf(task?.description ?: "") }
  var priority by remember { mutableStateOf(task?.priority ?: TaskPriority.MEDIUM.name) }
  var estimatedMinutes by remember { mutableIntStateOf(task?.estimatedMinutes ?: 30) }
  var tags by remember { mutableStateOf(task?.tags ?: "") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = if (task == null) (if (isPersian) "ثبت وظیفه جدید" else "New Actionable Task") else (if (isPersian) "ویرایش وظیفه" else "Edit Task"),
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text(if (isPersian) "عنوان وظیفه *" else "Task Title *") },
          modifier = Modifier.fillMaxWidth().testTag("dialog_task_title"),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text(if (isPersian) "توضیحات و معیارهای تکمیل" else "Description & Success Criteria") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        Text(text = if (isPersian) "اولویت:" else "Priority:", style = MaterialTheme.typography.labelSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("LOW", "MEDIUM", "HIGH", "URGENT").forEach { p ->
            val isSelected = priority == p
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) colors.accent else colors.elevatedSurface,
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { priority = p }
            ) {
              Text(
                text = p,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) colors.mainBackground else colors.primaryText,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
              )
            }
          }
        }

        OutlinedTextField(
          value = estimatedMinutes.toString(),
          onValueChange = { estimatedMinutes = it.toIntOrNull() ?: 30 },
          label = { Text(if (isPersian) "مدت تخمینی (دقیقه)" else "Estimated Minutes") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = tags,
          onValueChange = { tags = it },
          label = { Text(if (isPersian) "برچسب‌ها (با ویرگول جدا کنید)" else "Tags (comma separated)") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            onSave(
              task?.copy(
                title = title,
                description = description,
                priority = priority,
                estimatedMinutes = estimatedMinutes,
                tags = tags
              ) ?: TaskEntity(
                title = title,
                description = description,
                priority = priority,
                estimatedMinutes = estimatedMinutes,
                dueDate = todayDate,
                scheduledDate = todayDate,
                tags = tags
              )
            )
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
        modifier = Modifier.testTag("dialog_save_task_btn")
      ) {
        Text(if (isPersian) "ذخیره" else "Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(if (isPersian) "انصراف" else "Cancel")
      }
    }
  )
}

@Composable
fun HabitEditDialog(
  habit: HabitEntity?,
  isPersian: Boolean,
  onDismiss: () -> Unit,
  onSave: (HabitEntity) -> Unit
) {
  val colors = MaterialTheme.ascendColors

  var title by remember { mutableStateOf(habit?.title ?: "") }
  var description by remember { mutableStateOf(habit?.description ?: "") }
  var daysPerWeek by remember { mutableIntStateOf(habit?.targetDaysPerWeek ?: 7) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (habit == null) (if (isPersian) "عادت جدید" else "New Keystone Habit") else (if (isPersian) "ویرایش عادت" else "Edit Habit")) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text(if (isPersian) "عنوان عادت *" else "Habit Title *") },
          modifier = Modifier.fillMaxWidth().testTag("dialog_habit_title"),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text(if (isPersian) "توضیح (نسخه کوچک ۲ دقیقه‌ای)" else "Description (e.g. 2-minute version)") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = daysPerWeek.toString(),
          onValueChange = { daysPerWeek = it.toIntOrNull()?.coerceIn(1, 7) ?: 7 },
          label = { Text(if (isPersian) "روز در هفته (۱ تا ۷)" else "Days per Week (1-7)") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            onSave(
              habit?.copy(
                title = title,
                description = description,
                targetDaysPerWeek = daysPerWeek
              ) ?: HabitEntity(
                title = title,
                description = description,
                targetDaysPerWeek = daysPerWeek
              )
            )
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = colors.positive),
        modifier = Modifier.testTag("dialog_save_habit_btn")
      ) {
        Text(if (isPersian) "ذخیره" else "Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(if (isPersian) "انصراف" else "Cancel")
      }
    }
  )
}

@Composable
fun GoalEditDialog(
  goal: GoalEntity?,
  isPersian: Boolean,
  onDismiss: () -> Unit,
  onSave: (GoalEntity) -> Unit
) {
  val colors = MaterialTheme.ascendColors

  var title by remember { mutableStateOf(goal?.title ?: "") }
  var description by remember { mutableStateOf(goal?.description ?: "") }
  var motivation by remember { mutableStateOf(goal?.motivation ?: "") }
  var category by remember { mutableStateOf(goal?.category ?: LifeArea.CAREER.name) }
  var targetMetric by remember { mutableStateOf(goal?.targetMetric?.toString() ?: "100") }
  var unit by remember { mutableStateOf(goal?.metricUnit ?: "%") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (goal == null) (if (isPersian) "هدف استراتژیک جدید" else "New Strategic Goal") else (if (isPersian) "ویرایش هدف" else "Edit Goal")) },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text(if (isPersian) "عنوان هدف *" else "Goal Title *") },
          modifier = Modifier.fillMaxWidth().testTag("dialog_goal_title"),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text(if (isPersian) "توضیح و افق نهایی" else "Desired Outcome & Vision") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        OutlinedTextField(
          value = motivation,
          onValueChange = { motivation = it },
          label = { Text(if (isPersian) "چرا این هدف مهم است؟ (انگیزه)" else "Why does this matter? (Motivation)") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = targetMetric,
            onValueChange = { targetMetric = it },
            label = { Text(if (isPersian) "مقدار هدف" else "Target Value") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          )
          OutlinedTextField(
            value = unit,
            onValueChange = { unit = it },
            label = { Text(if (isPersian) "واحد" else "Unit") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp)
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            val targetVal = targetMetric.toDoubleOrNull() ?: 100.0
            onSave(
              goal?.copy(
                title = title,
                description = description,
                motivation = motivation,
                category = category,
                targetMetric = targetVal,
                metricUnit = unit
              ) ?: GoalEntity(
                title = title,
                description = description,
                motivation = motivation,
                category = category,
                targetMetric = targetVal,
                currentMetric = 0.0,
                metricUnit = unit
              )
            )
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
        modifier = Modifier.testTag("dialog_save_goal_btn")
      ) {
        Text(if (isPersian) "ذخیره" else "Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(if (isPersian) "انصراف" else "Cancel")
      }
    }
  )
}

@Composable
fun ProjectEditDialog(
  project: ProjectEntity?,
  isPersian: Boolean,
  onDismiss: () -> Unit,
  onSave: (ProjectEntity) -> Unit
) {
  val colors = MaterialTheme.ascendColors

  var name by remember { mutableStateOf(project?.name ?: "") }
  var description by remember { mutableStateOf(project?.description ?: "") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (project == null) (if (isPersian) "پروژه جدید" else "New Project") else (if (isPersian) "ویرایش پروژه" else "Edit Project")) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text(if (isPersian) "نام پروژه *" else "Project Name *") },
          modifier = Modifier.fillMaxWidth().testTag("dialog_project_name"),
          shape = RoundedCornerShape(10.dp)
        )
        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text(if (isPersian) "توضیحات" else "Description") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (name.isNotBlank()) {
            onSave(
              project?.copy(name = name, description = description) ?: ProjectEntity(
                name = name,
                description = description
              )
            )
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
      ) {
        Text(if (isPersian) "ذخیره" else "Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(if (isPersian) "انصراف" else "Cancel")
      }
    }
  )
}

@Composable
fun NoteEditDialog(
  note: NoteEntity?,
  isPersian: Boolean,
  onDismiss: () -> Unit,
  onSave: (NoteEntity) -> Unit
) {
  val colors = MaterialTheme.ascendColors

  var title by remember { mutableStateOf(note?.title ?: "") }
  var content by remember { mutableStateOf(note?.content ?: "") }
  var tags by remember { mutableStateOf(note?.tags ?: "") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (note == null) (if (isPersian) "یادداشت جدید" else "New Note") else (if (isPersian) "ویرایش یادداشت" else "Edit Note")) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text(if (isPersian) "عنوان یادداشت *" else "Note Title *") },
          modifier = Modifier.fillMaxWidth().testTag("dialog_note_title"),
          shape = RoundedCornerShape(10.dp)
        )
        OutlinedTextField(
          value = content,
          onValueChange = { content = it },
          label = { Text(if (isPersian) "متن یادداشت..." else "Content...") },
          modifier = Modifier.fillMaxWidth().height(140.dp),
          shape = RoundedCornerShape(10.dp)
        )
        OutlinedTextField(
          value = tags,
          onValueChange = { tags = it },
          label = { Text(if (isPersian) "برچسب‌ها" else "Tags") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            onSave(
              note?.copy(title = title, content = content, tags = tags) ?: NoteEntity(
                title = title,
                content = content,
                tags = tags
              )
            )
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
      ) {
        Text(if (isPersian) "ذخیره" else "Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text(if (isPersian) "انصراف" else "Cancel")
      }
    }
  )
}
