package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfileEntity
import com.example.ui.theme.ThemeMode
import com.example.ui.theme.ascendColors

@Composable
fun SettingsScreen(
  userProfile: UserProfileEntity?,
  currentTheme: ThemeMode,
  isPersian: Boolean,
  onUpdateTheme: (ThemeMode) -> Unit,
  onUpdateLanguage: (String) -> Unit,
  onUpdateProfile: (UserProfileEntity) -> Unit,
  onResetSampleData: () -> Unit,
  onExportJson: () -> String,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors

  var showExportDialog by remember { mutableStateOf(false) }
  var exportedJsonText by remember { mutableStateOf("") }
  var showResetDialog by remember { mutableStateOf(false) }

  var userName by remember(userProfile) { mutableStateOf(userProfile?.name ?: "Explorer") }
  var targetHours by remember(userProfile) { mutableStateOf((userProfile?.dailyTargetHours ?: 6).toFloat()) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
      .testTag("settings_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Personal Identity Profile
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "هویت کاربر و نام ترجیحی" else "User Identity & Profile",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = userName,
          onValueChange = {
            userName = it
            userProfile?.let { p -> onUpdateProfile(p.copy(name = it)) }
          },
          label = { Text(if (isPersian) "نام شما" else "Your Name") },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth().testTag("settings_name_input"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.accent,
            unfocusedBorderColor = colors.borderColor
          )
        )
      }
    }

    // 2. Visual Theme Selector
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "پوسته دیداری و رنگ‌ها" else "Appearance & Visual Theme",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          ThemeOptionButton(
            title = if (isPersian) "تاریک (لوکس)" else "Dark",
            isSelected = currentTheme == ThemeMode.DARK,
            onClick = { onUpdateTheme(ThemeMode.DARK) },
            modifier = Modifier.weight(1f)
          )
          ThemeOptionButton(
            title = if (isPersian) "روشن (تمیز)" else "Light",
            isSelected = currentTheme == ThemeMode.LIGHT,
            onClick = { onUpdateTheme(ThemeMode.LIGHT) },
            modifier = Modifier.weight(1f)
          )
          ThemeOptionButton(
            title = if (isPersian) "سیستم" else "System",
            isSelected = currentTheme == ThemeMode.SYSTEM,
            onClick = { onUpdateTheme(ThemeMode.SYSTEM) },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // 3. Language & RTL Selector
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "زبان و چیدمان راست‌به‌چپ (RTL)" else "Language & Direction (RTL)",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          ThemeOptionButton(
            title = "English (LTR)",
            isSelected = !isPersian,
            onClick = { onUpdateLanguage("en") },
            modifier = Modifier.weight(1f)
          )
          ThemeOptionButton(
            title = "فارسی (RTL)",
            isSelected = isPersian,
            onClick = { onUpdateLanguage("fa") },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // 4. Daily Work Capacity
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = if (isPersian) "ظرفیت کار روزانه هدف" else "Daily Target Capacity",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = colors.primaryText
          )
          Text(
            text = "${targetHours.toInt()} hours/day",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = colors.accent
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Slider(
          value = targetHours,
          onValueChange = {
            targetHours = it
            userProfile?.let { p -> onUpdateProfile(p.copy(dailyTargetHours = it.toInt())) }
          },
          valueRange = 2f..12f,
          steps = 9,
          colors = SliderDefaults.colors(
            thumbColor = colors.accent,
            activeTrackColor = colors.accent,
            inactiveTrackColor = colors.elevatedSurface
          ),
          modifier = Modifier.fillMaxWidth()
        )
      }
    }

    // 5. Data Sovereignty & Backup
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = if (isPersian) "حاکمیت بر داده‌ها و نسخه پشتیبان" else "Data Sovereignty & Portability",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = colors.primaryText
        )
        Text(
          text = if (isPersian) "داده‌های شما به‌صورت محلی در پایگاه داده پایدار Room ذخیره می‌شوند." else "Your tasks, habits, and goals are stored securely in local Room database.",
          style = MaterialTheme.typography.bodySmall,
          color = colors.secondaryText
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = {
              exportedJsonText = onExportJson()
              showExportDialog = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f).testTag("export_json_btn")
          ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isPersian) "پشتیبان JSON" else "Export JSON")
          }

          OutlinedButton(
            onClick = { showResetDialog = true },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f).testTag("reset_sample_data_btn")
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isPersian) "بازیابی نمونه" else "Reset Sample")
          }
        }
      }
    }

    // App Branding Footer
    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = "ASCEND OS v1.0.0",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = colors.accent
      )
      Text(
        text = "Design your days. Build your future.",
        style = MaterialTheme.typography.bodySmall,
        color = colors.secondaryText
      )
    }

    Spacer(modifier = Modifier.height(20.dp))
  }

  // Export Dialog
  if (showExportDialog) {
    AlertDialog(
      onDismissRequest = { showExportDialog = false },
      title = { Text(if (isPersian) "پشتیبان داده‌های صعود" else "ASCEND Data Export") },
      text = {
        OutlinedTextField(
          value = exportedJsonText,
          onValueChange = {},
          readOnly = true,
          modifier = Modifier.fillMaxWidth().height(250.dp),
          shape = RoundedCornerShape(10.dp)
        )
      },
      confirmButton = {
        Button(
          onClick = { showExportDialog = false },
          colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
        ) {
          Text(if (isPersian) "بستن" else "Close")
        }
      }
    )
  }

  // Reset Dialog
  if (showResetDialog) {
    AlertDialog(
      onDismissRequest = { showResetDialog = false },
      title = { Text(if (isPersian) "بازیابی داده‌های پیش‌فرض؟" else "Reset to Starter Pack?") },
      text = { Text(if (isPersian) "آیا می‌خواهید داده‌های نمونه پیش‌فرض را مجدداً فعال کنید؟" else "Re-seed the initial starter habits, goals, and projects?") },
      confirmButton = {
        Button(
          onClick = {
            onResetSampleData()
            showResetDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = colors.positive)
        ) {
          Text(if (isPersian) "تأیید" else "Confirm Reset")
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetDialog = false }) {
          Text(if (isPersian) "انصراف" else "Cancel")
        }
      }
    )
  }
}

@Composable
private fun ThemeOptionButton(
  title: String,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = if (isSelected) colors.accent else colors.elevatedSurface,
    border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, colors.borderColor) else null,
    modifier = modifier
      .clip(RoundedCornerShape(10.dp))
      .clickable { onClick() }
  ) {
    Box(
      modifier = Modifier.padding(vertical = 12.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        color = if (isSelected) colors.mainBackground else colors.primaryText
      )
    }
  }
}
