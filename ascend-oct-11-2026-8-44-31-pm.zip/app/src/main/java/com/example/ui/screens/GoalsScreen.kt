package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GoalEntity
import com.example.model.LifeArea
import com.example.ui.theme.ascendColors

@Composable
fun GoalsScreen(
  goals: List<GoalEntity>,
  isPersian: Boolean,
  onAddGoal: () -> Unit,
  onEditGoal: (GoalEntity) -> Unit,
  onDeleteGoal: (GoalEntity) -> Unit,
  onUpdateProgress: (GoalEntity, Double) -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  var selectedCategory by remember { mutableStateOf<String?>("ALL") }

  val filteredGoals = if (selectedCategory == "ALL" || selectedCategory == null) {
    goals
  } else {
    goals.filter { it.category == selectedCategory }
  }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddGoal,
        containerColor = colors.accent,
        contentColor = colors.mainBackground,
        shape = CircleShape,
        modifier = Modifier.testTag("fab_add_goal")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Goal")
      }
    },
    containerColor = colors.mainBackground,
    modifier = modifier.testTag("goals_screen")
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      // Category Filter Row
      val categories = listOf("ALL" to (if (isPersian) "همه حوزه‌ها" else "All Areas")) +
        LifeArea.values().map { it.name to it.title }

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(categories) { (key, label) ->
          val isSelected = selectedCategory == key
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (isSelected) colors.accent else colors.cardSurface,
            border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, colors.borderColor) else null,
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .clickable { selectedCategory = key }
              .testTag("goal_filter_$key")
          ) {
            Text(
              text = label,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) colors.mainBackground else colors.primaryText,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      if (filteredGoals.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Flag,
              contentDescription = null,
              tint = colors.secondaryText,
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = if (isPersian) "هنوز هدفی تعریف نشده است" else "No Goals Defined Yet",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = colors.primaryText
            )
            Text(
              text = if (isPersian) "با دکمه + در پایین، اولین افق بلندمدت خود را تعریف کنید." else "Tap + below to build your long-term roadmap.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(14.dp),
          modifier = Modifier.fillMaxSize().testTag("goals_lazy_column")
        ) {
          items(filteredGoals, key = { it.id }) { goal ->
            GoalCard(
              goal = goal,
              isPersian = isPersian,
              onEdit = { onEditGoal(goal) },
              onDelete = { onDeleteGoal(goal) },
              onProgressChange = { onUpdateProgress(goal, it) }
            )
          }
        }
      }
    }
  }
}

@Composable
private fun GoalCard(
  goal: GoalEntity,
  isPersian: Boolean,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onProgressChange: (Double) -> Unit
) {
  val colors = MaterialTheme.ascendColors

  val progressPercent = if (goal.targetMetric > 0) {
    ((goal.currentMetric / goal.targetMetric) * 100).toInt().coerceIn(0, 100)
  } else 0

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = colors.cardSurface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth().testTag("goal_card_${goal.id}")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = colors.accent.copy(alpha = 0.15f)
          ) {
            Text(
              text = goal.category,
              style = MaterialTheme.typography.labelSmall,
              color = colors.accent,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
          }

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = goal.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = colors.primaryText
          )

          if (goal.description.isNotBlank()) {
            Text(
              text = goal.description,
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }
        }

        Row {
          IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = colors.secondaryText, modifier = Modifier.size(16.dp))
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = colors.error.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
          }
        }
      }

      if (goal.motivation.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "\"${goal.motivation}\"",
          style = MaterialTheme.typography.bodySmall,
          fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
          color = colors.accent
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Progress bar and numbers
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "$progressPercent% Complete",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = colors.positive
        )
        Text(
          text = "${goal.currentMetric.toInt()} / ${goal.targetMetric.toInt()} ${goal.metricUnit}",
          style = MaterialTheme.typography.labelMedium,
          color = colors.secondaryText
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      LinearProgressIndicator(
        progress = { (progressPercent / 100f).coerceIn(0f, 1f) },
        modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
        color = colors.positive,
        trackColor = colors.elevatedSurface
      )

      Spacer(modifier = Modifier.height(8.dp))

      // Interactive slider to adjust metric
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = if (isPersian) "تنظیم پیشرفت:" else "Update Progress:",
          style = MaterialTheme.typography.labelSmall,
          color = colors.secondaryText
        )
        Spacer(modifier = Modifier.width(8.dp))
        Slider(
          value = goal.currentMetric.toFloat().coerceIn(0f, goal.targetMetric.toFloat()),
          onValueChange = { onProgressChange(it.toDouble()) },
          valueRange = 0f..maxOf(1f, goal.targetMetric.toFloat()),
          colors = SliderDefaults.colors(
            thumbColor = colors.accent,
            activeTrackColor = colors.accent,
            inactiveTrackColor = colors.elevatedSurface
          ),
          modifier = Modifier.weight(1f).testTag("goal_slider_${goal.id}")
        )
      }
    }
  }
}
