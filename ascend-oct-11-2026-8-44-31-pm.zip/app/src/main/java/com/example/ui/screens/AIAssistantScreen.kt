package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ascendColors
import com.example.viewmodel.ChatMessage

@Composable
fun AIAssistantScreen(
  messages: List<ChatMessage>,
  isLoading: Boolean,
  isPersian: Boolean,
  onSendMessage: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val colors = MaterialTheme.ascendColors
  var inputText by remember { mutableStateOf("") }
  val listState = rememberLazyListState()

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  val promptChips = listOf(
    if (isPersian) "🗓️ برنامه امروز من را بچین" else "🗓️ Architect my day schedule",
    if (isPersian) "🔨 بزرگترین وظیفه من را خرد کن" else "🔨 Break down my top priority",
    if (isPersian) "🛡️ برنامه ریکاوری بعد از روزهای از دست رفته" else "🛡️ Recovery plan after missed days",
    if (isPersian) "🎯 تحلیل پیشرفت در اهداف" else "🎯 Calibrate active goals & OKRs"
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp)
      .testTag("ai_assistant_screen")
  ) {
    // Quick prompt chips
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(promptChips) { chip ->
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = colors.cardSurface,
          border = androidx.compose.foundation.BorderStroke(1.dp, colors.borderColor),
          modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable {
              onSendMessage(chip)
            }
            .testTag("ai_prompt_chip")
        ) {
          Text(
            text = chip,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = colors.primaryText,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Messages history
    LazyColumn(
      state = listState,
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
    ) {
      items(messages) { message ->
        val isUser = message.sender == "user"
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
          if (!isUser) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(colors.accent),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = colors.mainBackground,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
          }

          Surface(
            shape = RoundedCornerShape(
              topStart = 16.dp,
              topEnd = 16.dp,
              bottomStart = if (isUser) 16.dp else 4.dp,
              bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            color = if (isUser) colors.accent else colors.cardSurface,
            modifier = Modifier.widthIn(max = 300.dp)
          ) {
            Text(
              text = message.text,
              style = MaterialTheme.typography.bodyMedium,
              color = if (isUser) colors.mainBackground else colors.primaryText,
              modifier = Modifier.padding(14.dp)
            )
          }
        }
      }

      if (isLoading) {
        item {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(8.dp)
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(20.dp),
              color = colors.accent,
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = if (isPersian) "دستیار در حال تحلیل داده‌ها و ساخت استراتژی..." else "Synthesizing strategy from your actual records...",
              style = MaterialTheme.typography.bodySmall,
              color = colors.secondaryText
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Input row
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedTextField(
        value = inputText,
        onValueChange = { inputText = it },
        placeholder = { Text(if (isPersian) "از دستیار صعود بپرسید..." else "Ask Ascend AI personal architect...") },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
          .weight(1f)
          .testTag("ai_input_field"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = colors.accent,
          unfocusedBorderColor = colors.borderColor
        )
      )

      Spacer(modifier = Modifier.width(8.dp))

      IconButton(
        onClick = {
          if (inputText.isNotBlank()) {
            val text = inputText
            inputText = ""
            onSendMessage(text)
          }
        },
        modifier = Modifier
          .size(48.dp)
          .clip(CircleShape)
          .background(colors.accent)
          .testTag("ai_send_button")
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.Send,
          contentDescription = "Send",
          tint = colors.mainBackground
        )
      }
    }
  }
}
